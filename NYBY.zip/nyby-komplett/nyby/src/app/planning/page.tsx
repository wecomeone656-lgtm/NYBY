'use client'
import { useState } from 'react'
import { useApi, apiPost } from '@/hooks/useApi'
import Spinner from '@/components/ui/Spinner'
import type { Resident, Meal, Activity } from '@/types'

const DAYS = ['Måndag','Tisdag','Onsdag','Torsdag','Fredag','Lördag','Söndag']
const MEAL_TYPES = ['Frukost','Lunch','Middag','Mellanmål']
const TIMES = ['Förmiddag','Eftermiddag','Kväll']

function getWeekNumber(d = new Date()) {
  const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()))
  date.setUTCDate(date.getUTCDate() + 4 - (date.getUTCDay() || 7))
  const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1))
  return Math.ceil((((date.getTime() - yearStart.getTime()) / 86400000) + 1) / 7)
}

export default function PlanningPage() {
  const [tab, setTab] = useState<'activities'|'meals'>('activities')
  const [week, setWeek] = useState(getWeekNumber())
  const [year] = useState(new Date().getFullYear())

  const { data: residents, loading: rLoad } = useApi<Resident[]>('/api/residents')
  const { data: meals, loading: mLoad, refetch: refetchMeals } = useApi<Meal[]>(
    `/api/planning/meals?week=${week}&year=${year}`, [week]
  )
  const { data: activities, loading: aLoad, refetch: refetchAct } = useApi<Activity[]>('/api/planning/activities')

  const resList = residents || []
  const mealList = meals || []
  const actList = activities || []

  function getMeal(day: number, mealType: string) {
    return mealList.find(m => m.day_of_week === day && m.meal_type === mealType.toLowerCase())?.description || ''
  }

  function getActivity(residentId: string, day: number, time: string) {
    return actList.find(a => a.resident_id === residentId && a.day_of_week === day && a.time_of_day === time.toLowerCase())?.title || ''
  }

  async function editMeal(day: number, mealType: string) {
    const current = getMeal(day, mealType)
    const val = prompt(`${DAYS[day-1]} – ${mealType}:`, current)
    if (val === null) return
    await apiPost('/api/planning/meals', { week_number: week, year, day_of_week: day, meal_type: mealType.toLowerCase(), description: val })
    refetchMeals()
  }

  async function editActivity(residentId: string, day: number, time: string) {
    const current = getActivity(residentId, day, time)
    const val = prompt(`${DAYS[day-1]} ${time}:`, current)
    if (val === null) return
    if (val === '') return // Rensning hanteras via DELETE i en utökad version
    const existing = actList.find(a => a.resident_id === residentId && a.day_of_week === day && a.time_of_day === time.toLowerCase())
    if (!existing) {
      await apiPost('/api/planning/activities', {
        resident_id: residentId, title: val,
        day_of_week: day, time_of_day: time.toLowerCase(), is_recurring: true,
      })
      refetchAct()
    }
  }

  if (rLoad) return <Spinner size="lg" />

  return (
    <div>
      <div className="flex gap-1 bg-gray-100 border border-gray-200 rounded-lg p-1 mb-5 w-fit">
        <button className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all ${tab==='activities' ? 'bg-white shadow text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}
          onClick={() => setTab('activities')}>Aktivitetsschema</button>
        <button className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all ${tab==='meals' ? 'bg-white shadow text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}
          onClick={() => setTab('meals')}>Matsedel</button>
      </div>

      {tab === 'meals' && (
        <div>
          <div className="flex items-center gap-3 mb-4">
            <button className="btn btn-secondary text-sm py-1.5" onClick={() => setWeek(w => w-1)}>‹ Föregående</button>
            <span className="font-semibold text-sm">Vecka {week}</span>
            <button className="btn btn-secondary text-sm py-1.5" onClick={() => setWeek(w => w+1)}>Nästa ›</button>
          </div>
          {mLoad ? <Spinner /> : (
            <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
              <div className="grid gap-px bg-gray-200" style={{ gridTemplateColumns: '100px repeat(7, 1fr)' }}>
                <div className="bg-gray-50 p-2 text-xs font-semibold text-gray-400" />
                {DAYS.map(d => <div key={d} className="bg-gray-50 p-2 text-center text-xs font-semibold text-gray-500">{d}</div>)}
                {MEAL_TYPES.map(meal => (
                  <>
                    <div key={`t-${meal}`} className="bg-gray-50 p-2 flex items-center text-xs font-semibold text-gray-600">{meal}</div>
                    {DAYS.map((_, i) => {
                      const val = getMeal(i+1, meal)
                      return (
                        <div key={i} className="bg-white p-2 min-h-[56px] cursor-pointer hover:bg-blue-50 transition-colors group"
                          onClick={() => editMeal(i+1, meal)}>
                          {val
                            ? <span className="inline-block bg-emerald-50 text-emerald-700 rounded px-2 py-0.5 text-xs">{val}</span>
                            : <span className="text-gray-300 text-xs group-hover:text-gray-400">+</span>}
                        </div>
                      )
                    })}
                  </>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {tab === 'activities' && (
        <div className="space-y-4">
          <p className="text-sm text-gray-500">Klicka på en cell för att lägga till eller redigera en aktivitet.</p>
          {aLoad ? <Spinner /> : resList.map(r => (
            <div key={r.id} className="bg-white border border-gray-200 rounded-xl overflow-hidden">
              <div className="flex items-center gap-2.5 px-4 py-3 border-b border-gray-100" style={{ background: r.color_code + '15' }}>
                <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold"
                  style={{ background: r.color_code }}>{r.full_name[0]}</div>
                <span className="font-semibold text-sm text-gray-900">{r.full_name}</span>
              </div>
              <div className="grid gap-px bg-gray-200" style={{ gridTemplateColumns: '90px repeat(7, 1fr)' }}>
                <div className="bg-gray-50" />
                {DAYS.map(d => <div key={d} className="bg-gray-50 p-2 text-center text-xs font-semibold text-gray-500">{d.slice(0,3)}</div>)}
                {TIMES.map(time => (
                  <>
                    <div key={`t-${time}`} className="bg-gray-50 p-2 flex items-center text-xs text-gray-500 font-medium">{time}</div>
                    {DAYS.map((_, i) => {
                      const val = getActivity(r.id, i+1, time)
                      return (
                        <div key={i} className="bg-white p-1.5 min-h-[52px] cursor-pointer hover:bg-blue-50 transition-colors group"
                          onClick={() => editActivity(r.id, i+1, time)}>
                          {val
                            ? <span className="inline-block bg-blue-50 text-blue-700 rounded px-1.5 py-0.5 text-xs leading-tight">{val}</span>
                            : <span className="text-gray-200 text-sm group-hover:text-gray-400">+</span>}
                        </div>
                      )
                    })}
                  </>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
