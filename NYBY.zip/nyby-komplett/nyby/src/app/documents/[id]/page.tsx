'use client'
import { useApi } from '@/hooks/useApi'
import Spinner from '@/components/ui/Spinner'
import Badge from '@/components/ui/Badge'
import Link from 'next/link'
import type { Document } from '@/types'

const CAT_LABEL: Record<string,string> = {
  genomforandeplan:'Genomförandeplan', skyddsatgard:'Skyddsåtgärd', avvikelse:'Avvikelse',
  bemotanderutin:'Bemötanderutin', kost_vatska:'Kost & Vätska', delegering:'Delegering',
}

export default function DocumentPage({ params }: { params: { id: string } }) {
  const { data: doc, loading } = useApi<Document>(`/api/documents/${params.id}`)

  if (loading) return <Spinner size="lg" />
  if (!doc) return <div className="text-gray-500 text-sm p-8">Dokument hittades inte.</div>

  const fields = doc.template?.fields || []
  const cat = doc.category || ''

  return (
    <div className="max-w-3xl">
      <div className="flex items-center gap-2 text-sm text-gray-400 mb-4">
        <Link href="/documents" className="hover:text-accent">Dokumentation</Link>
        <span>/</span>
        <span className="text-gray-600">{doc.title}</span>
      </div>

      <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
        {/* Header */}
        <div className="px-6 py-5 border-b border-gray-100" style={{ background: doc.resident ? doc.resident.color_code + '10' : undefined }}>
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-xl font-bold text-gray-900">{doc.title}</h1>
              <div className="flex items-center gap-3 mt-2">
                {doc.resident && (
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full" style={{ background: doc.resident.color_code }} />
                    <span className="text-sm text-gray-600">{doc.resident.full_name}</span>
                  </div>
                )}
                <Badge color="blue">{CAT_LABEL[cat] || 'Dokument'}</Badge>
                {doc.status === 'signed' && <Badge color="green">✓ Signerat</Badge>}
                {doc.status === 'draft' && <Badge color="gray">Utkast</Badge>}
              </div>
            </div>
            <Link href={`/documents/${doc.id}/edit`} className="btn btn-secondary text-sm">✎ Redigera</Link>
          </div>
          <div className="mt-3 text-xs text-gray-400 font-mono">
            Skapad {doc.created_at.slice(0, 10)}
            {doc.valid_until && <span className="ml-3 text-amber-600">Giltig t.o.m. {doc.valid_until}</span>}
          </div>
        </div>

        {/* Fält */}
        <div className="px-6 py-5 space-y-5">
          {fields.length > 0 ? fields.map(f => {
            const val = doc.fields?.[f.key]
            if (!val) return null
            return (
              <div key={f.key}>
                <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">{f.label}</div>
                <div className="text-sm text-gray-800 bg-gray-50 rounded-lg px-4 py-3 border border-gray-100 leading-relaxed whitespace-pre-wrap">{val}</div>
              </div>
            )
          }) : (
            Object.entries(doc.fields || {}).map(([k, v]) => v ? (
              <div key={k}>
                <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">{k}</div>
                <div className="text-sm text-gray-800 bg-gray-50 rounded-lg px-4 py-3 border border-gray-100">{v}</div>
              </div>
            ) : null)
          )}
        </div>

        {/* Signaturer */}
        {doc.signatures && doc.signatures.length > 0 && (
          <div className="px-6 py-4 border-t border-gray-100 bg-emerald-50">
            <div className="text-xs font-semibold text-emerald-700 uppercase tracking-wider mb-2">Signaturer</div>
            <div className="space-y-1">
              {doc.signatures.map(sig => (
                <div key={sig.id} className="flex items-center gap-2 text-sm text-emerald-800">
                  <span>✓</span>
                  <span className="font-medium">{sig.user?.full_name}</span>
                  <span className="text-emerald-600 text-xs">{sig.signed_at.slice(0, 16).replace('T', ' ')}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
