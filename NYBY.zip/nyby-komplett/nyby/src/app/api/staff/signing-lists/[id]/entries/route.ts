import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { requireAuth } from '@/lib/auth'
import { z } from 'zod'

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { user } = await requireAuth()
    const { task, user_id } = z.object({ task: z.string(), user_id: z.string() }).parse(await req.json())
    const uid = user_id || user.id
    const { data, error } = await supabaseAdmin
      .from('signing_entries').insert({ list_id: params.id, user_id: uid, task }).select().single()
    if (error) throw error
    return NextResponse.json({ data })
  } catch (e: unknown) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { user } = await requireAuth()
    const task = req.nextUrl.searchParams.get('task')
    const userId = req.nextUrl.searchParams.get('user_id') || user.id
    const { error } = await supabaseAdmin
      .from('signing_entries').delete().eq('list_id', params.id).eq('task', task || '').eq('user_id', userId)
    if (error) throw error
    return NextResponse.json({ success: true })
  } catch (e: unknown) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}
