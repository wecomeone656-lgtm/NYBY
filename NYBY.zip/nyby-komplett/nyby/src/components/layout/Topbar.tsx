'use client'
import { usePathname } from 'next/navigation'

const titles: Record<string, string> = {
  '/dashboard': 'Dashboard',
  '/residents': 'Boende',
  '/documents': 'Dokumentation',
  '/templates': 'Mallar',
  '/planning': 'Planering',
  '/staff': 'Personal',
}

export default function Topbar() {
  const pathname = usePathname()
  const title = Object.entries(titles).find(([path]) => pathname.startsWith(path))?.[1] || 'Nyby'
  const now = new Date().toLocaleDateString('sv-SE', { weekday: 'long', day: 'numeric', month: 'long' })
  return (
    <header className="bg-white border-b border-gray-200 h-14 flex items-center justify-between px-7 sticky top-0 z-40">
      <h2 className="text-sm font-semibold text-gray-900">{title}</h2>
      <span className="text-xs text-gray-400 capitalize">{now}</span>
    </header>
  )
}
