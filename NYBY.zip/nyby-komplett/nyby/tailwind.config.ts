import type { Config } from 'tailwindcss'
const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        sidebar: '#1c2030',
        accent: '#4a7cf7',
        'accent-hover': '#3668d8',
        success: '#5db88a',
        warning: '#e8b84b',
        danger: '#e07b54',
        purple: '#9b72e8',
        surface: '#f0f2f7',
      },
      fontFamily: { sans: ['DM Sans', 'system-ui', 'sans-serif'] },
    },
  },
  plugins: [],
}
export default config
