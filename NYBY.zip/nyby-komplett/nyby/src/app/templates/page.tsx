'use client'
import { useState } from 'react'
import { useApi, apiPost } from '@/hooks/useApi'
import Modal from '@/components/ui/Modal'
import Spinner from '@/components/ui/Spinner'
import { useRouter } from 'next/navigation'
import type { DocumentTemplate, Resident, TemplateField } from '@/types'

const CAT_META: Record<string, { label: string; color: string; tc: string; emoji: string }> = {
  genomforandeplan: { label:'Genomförandeplan', color:'#eff4fe', tc:'#3a7ae0', emoji:'⭐' },
  skyddsatgard:    { label:'Skyddsåtgärd',      color:'#fef2ee', tc:'#c0552a', emoji:'🛡️' },
  avvikelse:       { label:'Avvikelse',          color:'#fffbeb', tc:'#b45309', emoji:'⚠️' },
  bemotanderutin:  { label:'Bemötanderutin',     color:'#edfaf3', tc:'#3a9e6a', emoji:'💬' },
  kost_vatska:     { label:'Kost & Vätska',      color:'#f5f0ff', tc:'#7c3aed', emoji:'🍽️' },
  delegering:      { label:'Delegering',         color:'#f0f9ff', tc:'#0369a1', emoji:'📋' },
  signering:       { label:'Signering',          color:'#f3f4f6', tc:'#374151', emoji:'✅' },
}

export default function TemplatesPage() {
  const router = useRouter()
  const { data: templates, loading } = useApi<DocumentTemplate[]>('/api/templates')
  const { data: residents } = useApi<Resident[]>('/api/residents')
  const [open, setOpen] = useState(false)
  const [selectedTemplate, setSelectedTemplate] = useState<DocumentTemplate | null>(null)
  const [residentId, setResidentId] = useState('')
  const [title, setTitle] = useState('')
  const [fieldValues, setFieldValues] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  const tmplList = templates || []
  const resList = residents || []

  function selectTemplate(t: DocumentTemplate) {
    setSelectedTemplate(t)
    setTitle(t.name)
    setFieldValues({})
    setResidentId('')
    setError('')
    setOpen(true)
  }

  function setField(key: string, val: string) {
    setFieldValues(prev => ({ ...prev, [key]: val }))
  }

  async function save() {
    if (!residentId) { setError('Välj boende'); return }
    if (!title.trim()) { setError('Ange en titel'); return }
    setSaving(true); setError('')
    const { data, error: err } = await apiPost<{ id: string }>('/api/documents', {
      resident_id: residentId,
      template_id: selectedTemplate?.id,
      title: title.trim(),
      category: selectedTemplate?.category,
      fields: fieldValues,
    })
    setSaving(false)
    if (err) { setError(err); return }
    setOpen(false)
    if (data?.id) router.push(`/documents/${data.id}`)
  }

  function renderField(f: TemplateField) {
    const val = fieldValues[f.key] || ''
    const cls = "input text-sm"
    if (f.type === 'textarea') return (
      <textarea key={f.key} className={`${cls} resize-none`} rows={3} value={val}
        onChange={e => setField(f.key, e.target.value)} />
    )
    if (f.type === 'select') return (
      <select key={f.key} className={cls} value={val} onChange={e => setField(f.key, e.target.value)}>
        <option value="">Välj...</option>
        {(f.options || []).map(o => <option key={o}>{o}</option>)}
      </select>
    )
    return <input key={f.key} type={f.type} className={cls} value={val} onChange={e => setField(f.key, e.target.value)} />
  }

  if (loading) return <Spinner size="lg" />

  return (
    <div>
      <p className="text-sm text-gray-500 mb-5">Välj en mall för att skapa ett nytt dokument. Alla mallar är anpassade för LSS-verksamhet.</p>
      <div className="grid grid-cols-3 gap-4">
        {tmplList.map(t => {
          const meta = CAT_META[t.category] || { label: t.category, color: '#f3f4f6', tc: '#374151', emoji: '📄' }
          return (
            <button key={t.id} onClick={() => selectTemplate(t)}
              className="bg-white border border-gray-200 rounded-xl p-5 text-left hover:border-accent/50 hover:shadow-md transition-all group">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl mb-3"
                style={{ background: meta.color }}>{meta.emoji}</div>
              <div className="text-xs font-bold uppercase tracking-wider mb-0.5" style={{ color: meta.tc }}>{meta.label}</div>
              <div className="text-sm font-semibold text-gray-900 group-hover:text-accent">{t.name}</div>
              {t.description && <div className="text-xs text-gray-400 mt-1.5 leading-relaxed">{t.description}</div>}
              <div className="mt-3 text-xs text-gray-400">{t.fields.length} fält</div>
            </button>
          )
        })}
      </div>

      <Modal open={open} onClose={() => setOpen(false)}
        title={`Nytt dokument – ${selectedTemplate?.name}`}
        size="lg"
        footer={<>
          <button className="btn btn-secondary" onClick={() => setOpen(false)}>Avbryt</button>
          <button className="btn btn-primary" onClick={save} disabled={saving}>{saving ? 'Sparar...' : 'Spara dokument'}</button>
        </>}>
        {selectedTemplate && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label">Boende *</label>
                <select className="input" value={residentId} onChange={e => setResidentId(e.target.value)}>
                  <option value="">— Välj boende —</option>
                  {resList.map(r => <option key={r.id} value={r.id}>{r.full_name}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Titel *</label>
                <input className="input" value={title} onChange={e => setTitle(e.target.value)} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label">Giltig från</label>
                <input type="date" className="input" onChange={e => setField('valid_from', e.target.value)} />
              </div>
              <div>
                <label className="label">Giltig till</label>
                <input type="date" className="input" onChange={e => setField('valid_until', e.target.value)} />
              </div>
            </div>
            <div className="border-t border-gray-100 pt-4">
              {(selectedTemplate.fields || []).map(f => (
                <div key={f.key} className="mb-4">
                  <label className="label">{f.label}{f.required && <span className="text-red-400 ml-0.5">*</span>}</label>
                  {renderField(f)}
                </div>
              ))}
            </div>
            {error && <p className="text-red-600 text-sm bg-red-50 px-3 py-2 rounded-lg">{error}</p>}
          </div>
        )}
      </Modal>
    </div>
  )
}
