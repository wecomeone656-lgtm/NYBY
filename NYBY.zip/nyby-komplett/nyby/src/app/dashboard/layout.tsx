import Sidebar from '@/components/layout/Sidebar'
import Topbar from '@/components/layout/Topbar'

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen bg-surface">
      <Sidebar />
      <div className="ml-[230px] flex-1 flex flex-col">
        <Topbar />
        <main className="p-7 flex-1">{children}</main>
      </div>
    </div>
  )
}
