-- ============================================================
-- NYBY DOKUMENTATIONSSYSTEM – Databasschema v1.0
-- ============================================================

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─── ENHETER (Multi-tenant) ───────────────────────────────────
CREATE TABLE units (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,          -- ex. "nyby-halmstad"
  address TEXT,
  phone TEXT,
  manager_name TEXT,
  logo_url TEXT,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── ANVÄNDARE ────────────────────────────────────────────────
CREATE TYPE user_role AS ENUM (
  'admin',           -- Humana central IT
  'enhetschef',      -- Chef per enhet
  'personal',        -- Stödpedagog / undersköterska
  'vikarie',         -- Vikarie / timanställd
  'extern'           -- MAS, LSS-handläggare m.fl.
);

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  unit_id UUID REFERENCES units(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  full_name TEXT NOT NULL,
  role user_role NOT NULL DEFAULT 'personal',
  phone TEXT,
  -- TOTP
  totp_secret TEXT,                   -- Krypterad TOTP-hemlighet
  totp_enabled BOOLEAN DEFAULT false,
  totp_verified_at TIMESTAMPTZ,
  backup_codes TEXT[],                -- Hashade engångskoder
  -- Session
  last_login_at TIMESTAMPTZ,
  failed_login_attempts INT DEFAULT 0,
  locked_until TIMESTAMPTZ,
  -- Status
  active BOOLEAN DEFAULT true,
  must_change_password BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── AUDIT LOG ────────────────────────────────────────────────
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id),
  unit_id UUID REFERENCES units(id),
  action TEXT NOT NULL,               -- 'login', 'create_doc', 'delete_resident' etc.
  resource_type TEXT,                 -- 'document', 'resident', 'user'
  resource_id UUID,
  ip_address INET,
  user_agent TEXT,
  metadata JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── BOENDE ───────────────────────────────────────────────────
CREATE TABLE residents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  unit_id UUID NOT NULL REFERENCES units(id) ON DELETE CASCADE,
  -- Krypterade personuppgifter
  full_name TEXT NOT NULL,
  personal_number TEXT,               -- Krypterat i applagret
  date_of_birth DATE,
  room_number TEXT,
  lss_decision TEXT,
  lss_expiry DATE,
  color_code TEXT DEFAULT '#4a7cf7',  -- UI-färg
  photo_url TEXT,
  -- Status
  active BOOLEAN DEFAULT true,
  admitted_at DATE,
  discharged_at DATE,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Kontaktpersoner per boende
CREATE TABLE resident_contacts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  resident_id UUID NOT NULL REFERENCES residents(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  relation TEXT,                      -- 'god_man', 'anhörig', 'handläggare'
  phone TEXT,
  email TEXT,
  is_primary BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Vilka personal som ansvarar för vilka boende
CREATE TABLE resident_assignments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  resident_id UUID NOT NULL REFERENCES residents(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  is_primary BOOLEAN DEFAULT false,
  assigned_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(resident_id, user_id)
);

-- ─── DOKUMENTMALLAR ───────────────────────────────────────────
CREATE TYPE template_category AS ENUM (
  'genomforandeplan',
  'skyddsatgard',
  'avvikelse',
  'bemotanderutin',
  'kost_vatska',
  'delegering',
  'signering',
  'ovrigt'
);

CREATE TABLE document_templates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  unit_id UUID REFERENCES units(id) ON DELETE CASCADE, -- NULL = globalt
  category template_category NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  fields JSONB NOT NULL DEFAULT '[]', -- Array av fältdefinitioner
  is_system BOOLEAN DEFAULT false,    -- Inbyggd mall
  active BOOLEAN DEFAULT true,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── DOKUMENT ─────────────────────────────────────────────────
CREATE TYPE document_status AS ENUM (
  'draft',      -- Utkast
  'active',     -- Aktivt
  'signed',     -- Signerat
  'archived',   -- Arkiverat
  'superseded'  -- Ersatt av nyare version
);

CREATE TABLE documents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  unit_id UUID NOT NULL REFERENCES units(id) ON DELETE CASCADE,
  resident_id UUID NOT NULL REFERENCES residents(id) ON DELETE CASCADE,
  template_id UUID REFERENCES document_templates(id),
  title TEXT NOT NULL,
  category template_category,
  status document_status DEFAULT 'draft',
  fields JSONB DEFAULT '{}',          -- Ifyllt innehåll
  version INT DEFAULT 1,
  parent_id UUID REFERENCES documents(id), -- Föregående version
  valid_from DATE,
  valid_until DATE,
  created_by UUID REFERENCES users(id),
  updated_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Digitala signaturer
CREATE TABLE document_signatures (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id),
  role_at_signing user_role NOT NULL,
  signed_at TIMESTAMPTZ DEFAULT NOW(),
  ip_address INET,
  totp_verified BOOLEAN DEFAULT false,
  comment TEXT
);

-- ─── SIGNERINGSLISTOR ─────────────────────────────────────────
CREATE TABLE signing_lists (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  unit_id UUID NOT NULL REFERENCES units(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  period TEXT,
  tasks TEXT[] NOT NULL,              -- Insatser att signera
  active BOOLEAN DEFAULT true,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE signing_entries (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  list_id UUID NOT NULL REFERENCES signing_lists(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id),
  task TEXT NOT NULL,
  signed_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(list_id, user_id, task)
);

-- ─── PLANERING ────────────────────────────────────────────────
CREATE TABLE activities (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  unit_id UUID NOT NULL REFERENCES units(id) ON DELETE CASCADE,
  resident_id UUID REFERENCES residents(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  day_of_week INT,                    -- 1=Måndag, 7=Söndag
  time_of_day TEXT,                   -- 'förmiddag', 'eftermiddag', 'kväll'
  week_date DATE,                     -- Specifikt datum (om inte återkommande)
  is_recurring BOOLEAN DEFAULT false,
  assigned_to UUID REFERENCES users(id),
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE meals (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  unit_id UUID NOT NULL REFERENCES units(id) ON DELETE CASCADE,
  week_number INT NOT NULL,
  year INT NOT NULL,
  day_of_week INT NOT NULL,           -- 1–7
  meal_type TEXT NOT NULL,            -- 'frukost','lunch','middag','mellanmål'
  description TEXT NOT NULL,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(unit_id, week_number, year, day_of_week, meal_type)
);

-- ─── PERSONALSCHEMA ───────────────────────────────────────────
CREATE TABLE shifts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  unit_id UUID NOT NULL REFERENCES units(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  shift_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  shift_type TEXT DEFAULT 'dag',      -- 'dag','kväll','natt','jour'
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── ROW LEVEL SECURITY (RLS) ─────────────────────────────────
ALTER TABLE units ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE residents ENABLE ROW LEVEL SECURITY;
ALTER TABLE resident_contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE resident_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE document_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE document_signatures ENABLE ROW LEVEL SECURITY;
ALTER TABLE signing_lists ENABLE ROW LEVEL SECURITY;
ALTER TABLE signing_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE meals ENABLE ROW LEVEL SECURITY;
ALTER TABLE shifts ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- RLS: Användare ser bara sin enhets data
CREATE POLICY unit_isolation ON residents
  USING (unit_id = (SELECT unit_id FROM users WHERE id = auth.uid()));

CREATE POLICY unit_isolation ON documents
  USING (unit_id = (SELECT unit_id FROM users WHERE id = auth.uid()));

CREATE POLICY unit_isolation ON activities
  USING (unit_id = (SELECT unit_id FROM users WHERE id = auth.uid()));

CREATE POLICY unit_isolation ON meals
  USING (unit_id = (SELECT unit_id FROM users WHERE id = auth.uid()));

-- ─── TRIGGERS: updated_at ─────────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_units_updated_at BEFORE UPDATE ON units FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_residents_updated_at BEFORE UPDATE ON residents FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_documents_updated_at BEFORE UPDATE ON documents FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_meals_updated_at BEFORE UPDATE ON meals FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ─── INDEX ────────────────────────────────────────────────────
CREATE INDEX idx_users_unit ON users(unit_id);
CREATE INDEX idx_residents_unit ON residents(unit_id);
CREATE INDEX idx_documents_resident ON documents(resident_id);
CREATE INDEX idx_documents_unit ON documents(unit_id);
CREATE INDEX idx_documents_status ON documents(status);
CREATE INDEX idx_audit_user ON audit_logs(user_id);
CREATE INDEX idx_audit_created ON audit_logs(created_at);
CREATE INDEX idx_activities_unit ON activities(unit_id);
CREATE INDEX idx_meals_unit_week ON meals(unit_id, week_number, year);
CREATE INDEX idx_shifts_user_date ON shifts(user_id, shift_date);

