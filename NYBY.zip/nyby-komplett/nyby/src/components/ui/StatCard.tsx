interface Props { value: number | string; label: string; color?: string; icon?: string }
export default function StatCard({ value, label, color = '#4a7cf7', icon }: Props) {
  return (
    <div className="bg-white border border-gray-200 rounded-xl p-5">
      {icon && <div className="text-2xl mb-2">{icon}</div>}
      <div className="text-3xl font-bold" style={{ color }}>{value}</div>
      <div className="text-xs text-gray-500 mt-1">{label}</div>
    </div>
  )
}
