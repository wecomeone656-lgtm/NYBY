'use client'
import { useState } from 'react'
import { useApi, apiPost, apiDelete } from '@/hooks/useApi'
import Modal from '@/components/ui/Modal'
import EmptyState from '@/components/ui/EmptyState'
import Spinner from '@/components/ui/Spinner'
import Link from 'next/link'
import type { Resident } from '@/types'

const COLORS = ['#4a7cf7','#e07b54','#5db88a','#9b72e8','#e8b84b','#e07b9a','#5bbdcf','#e85454']

export default function ResidentsPage() {
  const { data, loading, refetch } = useApi<Resident[]>('/api/residents')
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<Resident | null>(null)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [form, setForm] = useState({
    full_name: '', personal_number: '', date_of_birth: '',
    room_number: '', lss_decision: '9§9', lss_expiry: '',
    color_code: '#4a7cf7', notes: '',
  })

  const residents = data || []

  function openNew() {
    setEditing(null)
    setForm({ full_name: '', personal_number: '', date_of_birth: '', room_number: '', lss_decision: '9§9', lss_expiry: '', color_code: '#4a7cf7', notes: '' })
    setError(''); setOpen(true)
  }

  function openEdit(r: Resident) {
    setEditing(r)
    setForm({ full_name: r.full_name, personal_number: r.personal_number || '', date_of_birth: r.date_of_birth || '', room_number: r.room_number || '', lss_decision: r.lss_decision || '9§9', lss_expiry: r.lss_expiry || '', color_code: r.color_code, notes: r.notes || '' })
    setError(''); setOpen(true)
  }

  async function save() {
    if (!form.full_name.trim()) { setError('Namn krävs'); return }
    setSaving(true); setError('')
    const url = editing ? `/api/residents/${editing.id}` : '/api/residents'
    const method = editing ? apiPost : apiPost // Both use POST; PATCH handled server side by id presence
    const { error: err } = editing
      ? await fetch(`/api/residents/${editing.id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) }).then(r => r.json())
      : await apiPost('/api/residents', form)
    setSaving(false)
    if (err) { setError(err); return }
    setOpen(false); refetch()
  }

  async function deleteResident(id: string) {
    if (!confirm('Ta bort boende? All dokumentation kopplas bort.')) return
    await apiDelete(`/api/residents/${id}`)
    refetch()
  }

  if (loading) return <Spinner size="lg" />

  return (
    <div>
      <div className="flex justify-end mb-5">
        <button className="btn btn-primary" onClick={openNew}>+ Lägg till boende</button>
      </div>

      {residents.length === 0 ? (
        <div className="bg-white rounded-xl border border-gray-200">
          <EmptyState icon="👥" title="Inga boende registrerade" description="Lägg till boende för att komma igång."
            action={<button className="btn btn-primary" onClick={openNew}>+ Lägg till boende</button>} />
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-4">
          {residents.map(r => (
            <div key={r.id} className="bg-white border border-gray-200 rounded-xl p-5 hover:border-gray-300 hover:shadow-sm transition-all">
              <div className="flex justify-between items-start mb-3">
                <div className="w-12 h-12 rounded-full flex items-center justify-center text-white text-xl font-bold"
                  style={{ background: r.color_code }}>{r.full_name[0]}</div>
                <div className="flex gap-2">
                  <button onClick={() => openEdit(r)} className="text-gray-400 hover:text-gray-700 p-1 rounded hover:bg-gray-100 transition-colors text-sm">✎</button>
                  <button onClick={() => deleteResident(r.id)} className="text-gray-400 hover:text-red-500 p-1 rounded hover:bg-red-50 transition-colors text-sm">🗑</button>
                </div>
              </div>
              <h3 className="font-semibold text-gray-900 text-base">{r.full_name}</h3>
              <p className="text-sm text-gray-400 mt-0.5">Rum {r.room_number} · LSS {r.lss_decision}</p>
              {r.date_of_birth && <p className="text-xs text-gray-400 mt-0.5">Född {r.date_of_birth}</p>}
              {r.lss_expiry && <p className="text-xs text-amber-600 mt-0.5">LSS utgår {r.lss_expiry}</p>}
              <div className="border-t border-gray-100 mt-3 pt-3">
                <Link href={`/documents?resident_id=${r.id}`}
                  className="text-xs text-accent hover:underline font-medium">Visa dokumentation →</Link>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)}
        title={editing ? 'Redigera boende' : 'Lägg till boende'}
        footer={<>
          <button className="btn btn-secondary" onClick={() => setOpen(false)}>Avbryt</button>
          <button className="btn btn-primary" onClick={save} disabled={saving}>{saving ? 'Sparar...' : 'Spara'}</button>
        </>}>
        <div className="space-y-4">
          <div>
            <label className="label">Namn *</label>
            <input className="input" value={form.full_name} onChange={e => setForm(f => ({ ...f, full_name: e.target.value }))} placeholder="Förnamn Efternamn" autoFocus />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Personnummer</label>
              <input className="input" value={form.personal_number} onChange={e => setForm(f => ({ ...f, personal_number: e.target.value }))} placeholder="YYYYMMDD-XXXX" />
            </div>
            <div>
              <label className="label">Rum</label>
              <input className="input" value={form.room_number} onChange={e => setForm(f => ({ ...f, room_number: e.target.value }))} placeholder="101" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Födelsedatum</label>
              <input type="date" className="input" value={form.date_of_birth} onChange={e => setForm(f => ({ ...f, date_of_birth: e.target.value }))} />
            </div>
            <div>
              <label className="label">LSS-beslut</label>
              <input className="input" value={form.lss_decision} onChange={e => setForm(f => ({ ...f, lss_decision: e.target.value }))} />
            </div>
          </div>
          <div>
            <label className="label">LSS-beslut utgångsdatum</label>
            <input type="date" className="input" value={form.lss_expiry} onChange={e => setForm(f => ({ ...f, lss_expiry: e.target.value }))} />
          </div>
          <div>
            <label className="label">Anteckningar</label>
            <textarea className="input resize-none h-20" value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
          </div>
          <div>
            <label className="label">Färg</label>
            <div className="flex gap-2 flex-wrap">
              {COLORS.map(c => (
                <button key={c} onClick={() => setForm(f => ({ ...f, color_code: c }))}
                  className={`w-7 h-7 rounded-full transition-all ${form.color_code === c ? 'ring-2 ring-offset-2 ring-gray-900 scale-110' : 'hover:scale-105'}`}
                  style={{ background: c }} />
              ))}
            </div>
          </div>
          {error && <p className="text-red-600 text-sm bg-red-50 px-3 py-2 rounded-lg">{error}</p>}
        </div>
      </Modal>
    </div>
  )
}
