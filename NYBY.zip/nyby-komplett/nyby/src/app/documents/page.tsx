'use client'
import { useState, Suspense } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import { useApi, apiDelete } from '@/hooks/useApi'
import EmptyState from '@/components/ui/EmptyState'
import Spinner from '@/components/ui/Spinner'
import Badge from '@/components/ui/Badge'
import Link from 'next/link'
import type { Document, Resident } from '@/types'

const CAT_LABEL: Record<string, string> = {
  genomforandeplan:'Genomförandeplan', skyddsatgard:'Skyddsåtgärd', avvikelse:'Avvikelse',
  bemotanderutin:'Bemötanderutin', kost_vatska:'Kost & Vätska', delegering:'Delegering', signering:'Signering',
}
const CAT_COLOR: Record<string, 'blue'|'green'|'red'|'yellow'|'gray'|'purple'> = {
  genomforandeplan:'blue', skyddsatgard:'red', avvikelse:'yellow',
  bemotanderutin:'green', kost_vatska:'purple', delegering:'gray', signering:'gray',
}
const STATUS_COLOR: Record<string, 'blue'|'green'|'gray'|'yellow'> = {
  draft:'gray', active:'blue', signed:'green', archived:'gray', superseded:'gray'
}
const STATUS_LABEL: Record<string, string> = {
  draft:'Utkast', active:'Aktivt', signed:'Signerat', archived:'Arkiverat'
}

function DocumentsContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const initRes = searchParams.get('resident_id') || ''
  const [filterRes, setFilterRes] = useState(initRes)
  const [filterCat, setFilterCat] = useState('')

  const { data: residents } = useApi<Resident[]>('/api/residents')
  const { data: docs, loading, refetch } = useApi<Document[]>(
    `/api/documents${filterRes ? `?resident_id=${filterRes}` : ''}${filterCat ? `${filterRes ? '&' : '?'}category=${filterCat}` : ''}`
  , [filterRes, filterCat])

  const docList = docs || []

  async function archiveDoc(id: string) {
    if (!confirm('Arkivera dokument?')) return
    await apiDelete(`/api/documents/${id}`)
    refetch()
  }

  return (
    <div>
      {/* Filter rad */}
      <div className="flex gap-3 mb-5 flex-wrap">
        <select className="input w-auto text-sm" value={filterRes} onChange={e => setFilterRes(e.target.value)}>
          <option value="">Alla boende</option>
          {(residents || []).map(r => <option key={r.id} value={r.id}>{r.full_name}</option>)}
        </select>
        <select className="input w-auto text-sm" value={filterCat} onChange={e => setFilterCat(e.target.value)}>
          <option value="">Alla kategorier</option>
          {Object.entries(CAT_LABEL).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </select>
        <Link href="/templates" className="btn btn-primary ml-auto">+ Nytt dokument</Link>
      </div>

      {loading ? <Spinner /> : docList.length === 0 ? (
        <div className="bg-white rounded-xl border border-gray-200">
          <EmptyState icon="📝" title="Inga dokument" description="Skapa ditt första dokument från en mall."
            action={<Link href="/templates" className="btn btn-primary">Välj mall</Link>} />
        </div>
      ) : (
        <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider px-4 py-3">Titel</th>
                <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider px-4 py-3">Typ</th>
                <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider px-4 py-3">Boende</th>
                <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider px-4 py-3">Status</th>
                <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider px-4 py-3">Datum</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {docList.map(doc => (
                <tr key={doc.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3">
                    <button onClick={() => router.push(`/documents/${doc.id}`)} className="font-semibold text-sm text-gray-900 hover:text-accent text-left">
                      {doc.title}
                    </button>
                  </td>
                  <td className="px-4 py-3">
                    <Badge color={CAT_COLOR[doc.category || ''] || 'gray'}>{CAT_LABEL[doc.category || ''] || '–'}</Badge>
                  </td>
                  <td className="px-4 py-3">
                    {doc.resident && (
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full" style={{ background: doc.resident.color_code }} />
                        <span className="text-sm text-gray-700">{doc.resident.full_name}</span>
                      </div>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <Badge color={STATUS_COLOR[doc.status] || 'gray'}>{STATUS_LABEL[doc.status] || doc.status}</Badge>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-400 font-mono">{doc.created_at.slice(0, 10)}</td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      <Link href={`/documents/${doc.id}`} className="btn btn-secondary text-xs px-3 py-1.5">Visa</Link>
                      <button onClick={() => archiveDoc(doc.id)} className="btn btn-danger text-xs px-2 py-1.5">🗑</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

export default function DocumentsPage() {
  return <Suspense fallback={<Spinner />}><DocumentsContent /></Suspense>
}
