import { SignJWT, jwtVerify } from 'jose'
import { cookies } from 'next/headers'
import { supabaseAdmin } from './supabase'
import type { User, Session } from '@/types'

const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || 'fallback-dev-secret-min-32-chars!!')
const SESSION_DURATION = 8 * 60 * 60 // 8 timmar i sekunder

export async function createSession(user: User): Promise<string> {
  const expiresAt = new Date(Date.now() + SESSION_DURATION * 1000)
  const token = await new SignJWT({
    sub: user.id,
    unit_id: user.unit_id,
    role: user.role,
    email: user.email,
  })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(expiresAt)
    .sign(JWT_SECRET)
  return token
}

export async function verifySession(token: string) {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET)
    return payload as { sub: string; unit_id: string; role: string; email: string; exp: number }
  } catch {
    return null
  }
}

export async function getSession(): Promise<{ user: User } | null> {
  const cookieStore = cookies()
  const token = cookieStore.get('nyby_session')?.value
  if (!token) return null

  const payload = await verifySession(token)
  if (!payload) return null

  const { data: user } = await supabaseAdmin
    .from('users')
    .select('*, unit:units(*)')
    .eq('id', payload.sub)
    .eq('active', true)
    .single()

  if (!user) return null
  return { user }
}

export async function requireAuth() {
  const session = await getSession()
  if (!session) throw new Error('UNAUTHORIZED')
  return session
}

export async function requireRole(allowedRoles: string[]) {
  const session = await requireAuth()
  if (!allowedRoles.includes(session.user.role)) throw new Error('FORBIDDEN')
  return session
}
