import { authenticator } from 'otplib'
import QRCode from 'qrcode'
import crypto from 'crypto'
import bcrypt from 'bcryptjs'

const APP_NAME = process.env.NEXT_PUBLIC_APP_NAME || 'Nyby Dokumentationssystem'
const ENCRYPTION_KEY = process.env.JWT_SECRET || 'fallback-dev-secret-min-32-chars!!'

// Kryptera TOTP-hemlighet för lagring i DB
export function encryptSecret(secret: string): string {
  const key = crypto.scryptSync(ENCRYPTION_KEY, 'salt', 32)
  const iv = crypto.randomBytes(16)
  const cipher = crypto.createCipheriv('aes-256-cbc', key, iv)
  const encrypted = Buffer.concat([cipher.update(secret, 'utf8'), cipher.final()])
  return iv.toString('hex') + ':' + encrypted.toString('hex')
}

export function decryptSecret(encryptedSecret: string): string {
  const [ivHex, encHex] = encryptedSecret.split(':')
  const key = crypto.scryptSync(ENCRYPTION_KEY, 'salt', 32)
  const iv = Buffer.from(ivHex, 'hex')
  const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv)
  const decrypted = Buffer.concat([decipher.update(Buffer.from(encHex, 'hex')), decipher.final()])
  return decrypted.toString('utf8')
}

// Skapa ny TOTP-hemlighet och QR-kod
export async function generateTOTPSetup(email: string): Promise<{
  secret: string
  encryptedSecret: string
  qrDataUrl: string
  backupCodes: string[]
  hashedBackupCodes: string[]
}> {
  authenticator.options = { step: 30, digits: 6 }
  const secret = authenticator.generateSecret(32)
  const otpauth = authenticator.keyuri(email, APP_NAME, secret)
  const qrDataUrl = await QRCode.toDataURL(otpauth, { width: 256, margin: 2 })
  const encryptedSecret = encryptSecret(secret)

  // Generera 8 backup-koder
  const backupCodes = Array.from({ length: 8 }, () =>
    crypto.randomBytes(4).toString('hex').toUpperCase()
  )
  const hashedBackupCodes = await Promise.all(
    backupCodes.map(code => bcrypt.hash(code, 12))
  )

  return { secret, encryptedSecret, qrDataUrl, backupCodes, hashedBackupCodes }
}

// Verifiera TOTP-kod
export function verifyTOTP(encryptedSecret: string, token: string): boolean {
  try {
    const secret = decryptSecret(encryptedSecret)
    authenticator.options = { step: 30, digits: 6, window: 1 }
    return authenticator.verify({ token, secret })
  } catch {
    return false
  }
}

// Verifiera backup-kod (engångsanvändning)
export async function verifyBackupCode(
  code: string,
  hashedCodes: string[]
): Promise<{ valid: boolean; index: number }> {
  for (let i = 0; i < hashedCodes.length; i++) {
    const match = await bcrypt.compare(code, hashedCodes[i])
    if (match) return { valid: true, index: i }
  }
  return { valid: false, index: -1 }
}
