import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { requireAuth, requireRole } from '@/lib/auth'
import { logAction } from '@/lib/audit'
import { z } from 'zod'

const schema = z.object({
  full_name: z.string().min(1),
  personal_number: z.string().optional(),
  date_of_birth: z.string().optional(),
  room_number: z.string().optional(),
  lss_decision: z.string().optional(),
  lss_expiry: z.string().optional(),
  color_code: z.string().default('#4a7cf7'),
  notes: z.string().optional(),
})

export async function GET() {
  try {
    const { user } = await requireAuth()
    const { data, error } = await supabaseAdmin
      .from('residents')
      .select('*, contacts:resident_contacts(*)')
      .eq('unit_id', user.unit_id)
      .eq('active', true)
      .order('full_name')
    if (error) throw error
    return NextResponse.json({ data })
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : 'Fel'
    if (msg === 'UNAUTHORIZED') return NextResponse.json({ error: 'Ej inloggad' }, { status: 401 })
    return NextResponse.json({ error: msg }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const { user } = await requireRole(['admin', 'enhetschef', 'personal'])
    const body = schema.parse(await req.json())
    const { data, error } = await supabaseAdmin
      .from('residents').insert({ ...body, unit_id: user.unit_id }).select().single()
    if (error) throw error
    await logAction({ user_id: user.id, unit_id: user.unit_id, action: 'create_resident', resource_type: 'resident', resource_id: data.id })
    return NextResponse.json({ data }, { status: 201 })
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : 'Fel'
    if (msg === 'UNAUTHORIZED') return NextResponse.json({ error: 'Ej inloggad' }, { status: 401 })
    if (msg === 'FORBIDDEN') return NextResponse.json({ error: 'Otillräcklig behörighet' }, { status: 403 })
    return NextResponse.json({ error: msg }, { status: 500 })
  }
}
