// ─── ENHETER ──────────────────────────────────────────────────
export interface Unit {
  id: string
  name: string
  slug: string
  address?: string
  phone?: string
  manager_name?: string
  logo_url?: string
  active: boolean
  created_at: string
  updated_at: string
}

// ─── ANVÄNDARE ────────────────────────────────────────────────
export type UserRole = 'admin' | 'enhetschef' | 'personal' | 'vikarie' | 'extern'

export interface User {
  id: string
  unit_id: string
  email: string
  full_name: string
  role: UserRole
  phone?: string
  totp_enabled: boolean
  active: boolean
  must_change_password: boolean
  last_login_at?: string
  created_at: string
  updated_at: string
  unit?: Unit
}

export interface AuthUser extends User {
  totp_secret?: string
}

// ─── BOENDE ───────────────────────────────────────────────────
export interface Resident {
  id: string
  unit_id: string
  full_name: string
  personal_number?: string
  date_of_birth?: string
  room_number?: string
  lss_decision?: string
  lss_expiry?: string
  color_code: string
  photo_url?: string
  active: boolean
  admitted_at?: string
  notes?: string
  created_at: string
  updated_at: string
  contacts?: ResidentContact[]
}

export interface ResidentContact {
  id: string
  resident_id: string
  name: string
  relation?: string
  phone?: string
  email?: string
  is_primary: boolean
}

// ─── DOKUMENTMALLAR ───────────────────────────────────────────
export type TemplateCategory =
  | 'genomforandeplan' | 'skyddsatgard' | 'avvikelse'
  | 'bemotanderutin' | 'kost_vatska' | 'delegering'
  | 'signering' | 'ovrigt'

export interface TemplateField {
  key: string
  label: string
  type: 'text' | 'textarea' | 'date' | 'datetime-local' | 'number' | 'select'
  required: boolean
  options?: string[]
}

export interface DocumentTemplate {
  id: string
  unit_id?: string
  category: TemplateCategory
  name: string
  description?: string
  fields: TemplateField[]
  is_system: boolean
  active: boolean
  created_at: string
}

// ─── DOKUMENT ─────────────────────────────────────────────────
export type DocumentStatus = 'draft' | 'active' | 'signed' | 'archived' | 'superseded'

export interface Document {
  id: string
  unit_id: string
  resident_id: string
  template_id?: string
  title: string
  category?: TemplateCategory
  status: DocumentStatus
  fields: Record<string, string>
  version: number
  parent_id?: string
  valid_from?: string
  valid_until?: string
  created_by: string
  updated_by?: string
  created_at: string
  updated_at: string
  resident?: Resident
  template?: DocumentTemplate
  created_by_user?: User
  signatures?: DocumentSignature[]
}

export interface DocumentSignature {
  id: string
  document_id: string
  user_id: string
  role_at_signing: UserRole
  signed_at: string
  totp_verified: boolean
  comment?: string
  user?: User
}

// ─── SIGNERINGSLISTOR ─────────────────────────────────────────
export interface SigningList {
  id: string
  unit_id: string
  title: string
  period?: string
  tasks: string[]
  active: boolean
  created_at: string
  entries?: SigningEntry[]
}

export interface SigningEntry {
  id: string
  list_id: string
  user_id: string
  task: string
  signed_at: string
  user?: User
}

// ─── PLANERING ────────────────────────────────────────────────
export interface Activity {
  id: string
  unit_id: string
  resident_id?: string
  title: string
  description?: string
  day_of_week?: number
  time_of_day?: string
  week_date?: string
  is_recurring: boolean
  assigned_to?: string
  created_at: string
  resident?: Resident
}

export interface Meal {
  id: string
  unit_id: string
  week_number: number
  year: number
  day_of_week: number
  meal_type: string
  description: string
  created_at: string
}

// ─── API SVAR ─────────────────────────────────────────────────
export interface ApiResponse<T> {
  data?: T
  error?: string
  message?: string
}

// ─── AUTH ─────────────────────────────────────────────────────
export interface LoginCredentials {
  email: string
  password: string
  totp_code?: string
}

export interface TOTPSetup {
  secret: string
  qr_url: string
  backup_codes: string[]
}

export interface Session {
  user: User
  token: string
  expires_at: string
}
