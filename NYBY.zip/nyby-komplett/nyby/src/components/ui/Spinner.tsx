export default function Spinner({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  const s = { sm: 'w-4 h-4', md: 'w-6 h-6', lg: 'w-10 h-10' }
  return (
    <div className="flex justify-center items-center p-8">
      <div className={`${s[size]} border-2 border-gray-200 border-t-accent rounded-full animate-spin`} />
    </div>
  )
}
