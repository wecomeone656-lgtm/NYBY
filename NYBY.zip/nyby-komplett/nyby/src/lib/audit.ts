import { supabaseAdmin } from './supabase'

export async function logAction(params: {
  user_id: string
  unit_id: string
  action: string
  resource_type?: string
  resource_id?: string
  ip_address?: string
  metadata?: Record<string, unknown>
}) {
  await supabaseAdmin.from('audit_logs').insert(params)
}
