'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

const navItems = [
  { href: '/dashboard', label: 'Dashboard', section: null, icon: 'M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z' },
  { href: '/residents', label: 'Boende', section: 'Boende', icon: 'M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z' },
  { href: '/documents', label: 'Dokumentation', section: 'Dokumentation', icon: 'M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z' },
  { href: '/templates', label: 'Mallar', section: null, icon: 'M19 2h-4.18C14.4.84 13.3 0 12 0c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm7 18H5V4h2v3h10V4h2v16z' },
  { href: '/planning', label: 'Planering', section: 'Planering', icon: 'M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM7 10h5v5H7z' },
  { href: '/staff', label: 'Personal', section: 'Personal', icon: 'M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z' },
]

export default function Sidebar() {
  const pathname = usePathname()
  let lastSection: string | null = null

  return (
    <aside className="w-[230px] bg-sidebar text-gray-300 fixed top-0 left-0 bottom-0 flex flex-col z-50 overflow-y-auto">
      <div className="px-5 pt-6 pb-4 border-b border-white/5">
        <h1 className="text-white text-sm font-bold">Nyby Gruppbostad</h1>
        <p className="text-gray-500 text-xs mt-0.5">Humana LSS · Dokumentation</p>
      </div>
      <nav className="flex-1 py-3">
        {navItems.map(item => {
          const showSection = item.section && item.section !== lastSection
          if (item.section) lastSection = item.section
          const isActive = pathname === item.href || (item.href !== '/dashboard' && pathname.startsWith(item.href))
          return (
            <div key={item.href}>
              {showSection && (
                <div className="px-5 pt-3 pb-1 text-[10px] font-bold tracking-widest uppercase text-gray-600">
                  {item.section}
                </div>
              )}
              <Link href={item.href}
                className={`flex items-center gap-2.5 px-5 py-2.5 text-sm border-l-[3px] transition-all ${
                  isActive
                    ? 'bg-white/10 text-white border-accent font-medium'
                    : 'border-transparent text-gray-400 hover:bg-white/5 hover:text-gray-200'
                }`}>
                <svg className="w-4 h-4 flex-shrink-0 opacity-80" fill="currentColor" viewBox="0 0 24 24">
                  <path d={item.icon} />
                </svg>
                {item.label}
              </Link>
            </div>
          )
        })}
      </nav>
      <div className="px-5 py-4 border-t border-white/5">
        <form action="/api/auth/logout" method="POST">
          <button className="text-xs text-gray-500 hover:text-gray-300 transition-colors w-full text-left">
            Logga ut
          </button>
        </form>
        <p className="text-[10px] text-gray-600 mt-2">{new Date().toLocaleDateString('sv-SE')}</p>
      </div>
    </aside>
  )
}
