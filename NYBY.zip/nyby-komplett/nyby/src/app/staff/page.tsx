'use client'
import { useState } from 'react'
import { useApi, apiPost, apiDelete } from '@/hooks/useApi'
import Modal from '@/components/ui/Modal'
import EmptyState from '@/components/ui/EmptyState'
import Spinner from '@/components/ui/Spinner'
import Badge from '@/components/ui/Badge'
import type { User, SigningList, SigningEntry } from '@/types'

const ROLE_LABEL: Record<string, string> = {
  enhetschef:'Enhetschef', personal:'Stödpedagog/Undersköterska',
  vikarie:'Vikarie', extern:'Extern', admin:'Admin',
}

export default function StaffPage() {
  const [tab, setTab] = useState<'list'|'signing'>('list')
  const { data: staffList, loading: sLoad, refetch: refetchStaff } = useApi<User[]>('/api/staff')
  const { data: signingLists, loading: slLoad, refetch: refetchSigning } = useApi<SigningList[]>('/api/staff/signing-lists')

  // Staff modal
  const [staffOpen, setStaffOpen] = useState(false)
  const [staffForm, setStaffForm] = useState({ full_name:'', email:'', role:'personal', phone:'', password:'' })
  const [staffError, setStaffError] = useState('')
  const [staffSaving, setStaffSaving] = useState(false)

  // Signing modal
  const [signOpen, setSignOpen] = useState(false)
  const [signForm, setSignForm] = useState({ title:'', period:'', tasks:'' })
  const [signError, setSignError] = useState('' )
  const [signSaving, setSignSaving] = useState(false)

  async function saveStaff() {
    if (!staffForm.full_name || !staffForm.email || !staffForm.password) { setStaffError('Fyll i alla obligatoriska fält'); return }
    setStaffSaving(true); setStaffError('')
    const { error } = await apiPost('/api/staff', staffForm)
    setStaffSaving(false)
    if (error) { setStaffError(error); return }
    setStaffOpen(false)
    setStaffForm({ full_name:'', email:'', role:'personal', phone:'', password:'' })
    refetchStaff()
  }

  async function saveSigning() {
    if (!signForm.title || !signForm.tasks) { setSignError('Fyll i namn och insatser'); return }
    setSignSaving(true); setSignError('')
    const tasks = signForm.tasks.split('\n').map(s => s.trim()).filter(Boolean)
    const { error } = await apiPost('/api/staff/signing-lists', { title: signForm.title, period: signForm.period, tasks })
    setSignSaving(false)
    if (error) { setSignError(error); return }
    setSignOpen(false)
    setSignForm({ title:'', period:'', tasks:'' })
    refetchSigning()
  }

  async function toggleSign(listId: string, task: string, userId: string, signed: boolean) {
    if (signed) {
      await apiDelete(`/api/staff/signing-lists/${listId}/entries?task=${encodeURIComponent(task)}&user_id=${userId}`)
    } else {
      await apiPost(`/api/staff/signing-lists/${listId}/entries`, { task, user_id: userId })
    }
    refetchSigning()
  }

  if (sLoad) return <Spinner size="lg" />

  const staff = staffList || []
  const lists = signingLists || []

  return (
    <div>
      <div className="flex gap-1 bg-gray-100 border border-gray-200 rounded-lg p-1 mb-5 w-fit">
        <button className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all ${tab==='list' ? 'bg-white shadow text-gray-900' : 'text-gray-500'}`}
          onClick={() => setTab('list')}>Personalregister</button>
        <button className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all ${tab==='signing' ? 'bg-white shadow text-gray-900' : 'text-gray-500'}`}
          onClick={() => setTab('signing')}>Signeringslistor</button>
      </div>

      {tab === 'list' && (
        <div>
          <div className="flex justify-end mb-4">
            <button className="btn btn-primary" onClick={() => setStaffOpen(true)}>+ Lägg till personal</button>
          </div>
          {staff.length === 0 ? (
            <div className="bg-white border border-gray-200 rounded-xl">
              <EmptyState icon="👤" title="Ingen personal tillagd" action={<button className="btn btn-primary" onClick={() => setStaffOpen(true)}>+ Lägg till personal</button>} />
            </div>
          ) : (
            <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
              <table className="w-full">
                <thead><tr className="bg-gray-50 border-b border-gray-200">
                  <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider px-4 py-3">Namn</th>
                  <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider px-4 py-3">Roll</th>
                  <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider px-4 py-3">E-post</th>
                  <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider px-4 py-3">2FA</th>
                  <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider px-4 py-3">Senaste login</th>
                </tr></thead>
                <tbody>
                  {staff.map(s => (
                    <tr key={s.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="px-4 py-3 font-semibold text-sm text-gray-900">{s.full_name}</td>
                      <td className="px-4 py-3"><Badge color="blue">{ROLE_LABEL[s.role] || s.role}</Badge></td>
                      <td className="px-4 py-3 text-sm text-gray-500">{s.email}</td>
                      <td className="px-4 py-3">
                        <Badge color={s.totp_enabled ? 'green' : 'yellow'}>{s.totp_enabled ? '✓ Aktiv' : '⚠ Ej aktiverat'}</Badge>
                      </td>
                      <td className="px-4 py-3 text-xs text-gray-400 font-mono">{s.last_login_at?.slice(0,16).replace('T',' ') || '–'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {tab === 'signing' && (
        <div>
          <div className="flex justify-end mb-4">
            <button className="btn btn-primary" onClick={() => setSignOpen(true)}>+ Ny signeringslista</button>
          </div>
          {slLoad ? <Spinner /> : lists.length === 0 ? (
            <div className="bg-white border border-gray-200 rounded-xl">
              <EmptyState icon="✅" title="Inga signeringslistor" action={<button className="btn btn-primary" onClick={() => setSignOpen(true)}>+ Skapa lista</button>} />
            </div>
          ) : (
            <div className="space-y-4">
              {lists.map(list => {
                const total = list.tasks.length * staff.length
                const done = (list.entries || []).length
                const pct = total > 0 ? Math.round(done / total * 100) : 0
                return (
                  <details key={list.id} className="bg-white border border-gray-200 rounded-xl overflow-hidden group">
                    <summary className="flex items-center justify-between px-5 py-4 cursor-pointer hover:bg-gray-50 list-none">
                      <div>
                        <div className="font-semibold text-sm text-gray-900">{list.title} <span className="text-gray-400 font-normal">{list.period}</span></div>
                        <div className="text-xs text-gray-400 mt-0.5">{done}/{total} signeringar</div>
                        <div className="mt-1.5 h-1.5 w-48 bg-gray-200 rounded-full overflow-hidden">
                          <div className="h-full bg-accent rounded-full transition-all" style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge color={pct === 100 ? 'green' : 'blue'}>{pct}%</Badge>
                        <span className="text-gray-400 text-sm group-open:rotate-180 transition-transform">▾</span>
                      </div>
                    </summary>
                    <div className="px-5 pb-5 border-t border-gray-100">
                      {list.tasks.map(task => (
                        <div key={task}>
                          <div className="text-xs font-bold text-gray-400 uppercase tracking-wider py-3">{task}</div>
                          {staff.map(s => {
                            const signed = (list.entries || []).some(e => e.task === task && e.user_id === s.id)
                            return (
                              <div key={s.id} className="flex items-center gap-3 py-2 border-b border-gray-50">
                                <button onClick={() => toggleSign(list.id, task, s.id, signed)}
                                  className={`w-5 h-5 rounded flex items-center justify-center flex-shrink-0 transition-all text-xs border-2 ${
                                    signed ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-gray-300 hover:border-accent'
                                  }`}>{signed ? '✓' : ''}</button>
                                <span className="text-sm text-gray-800">{s.full_name}</span>
                                {signed && <span className="text-xs text-emerald-600 ml-auto">Signerat</span>}
                              </div>
                            )
                          })}
                        </div>
                      ))}
                    </div>
                  </details>
                )
              })}
            </div>
          )}
        </div>
      )}

      {/* Modal: Lägg till personal */}
      <Modal open={staffOpen} onClose={() => setStaffOpen(false)} title="Lägg till personal"
        footer={<>
          <button className="btn btn-secondary" onClick={() => setStaffOpen(false)}>Avbryt</button>
          <button className="btn btn-primary" onClick={saveStaff} disabled={staffSaving}>{staffSaving ? 'Sparar...' : 'Spara'}</button>
        </>}>
        <div className="space-y-4">
          <div><label className="label">Namn *</label><input className="input" value={staffForm.full_name} onChange={e => setStaffForm(f => ({...f, full_name: e.target.value}))} /></div>
          <div><label className="label">E-post *</label><input type="email" className="input" value={staffForm.email} onChange={e => setStaffForm(f => ({...f, email: e.target.value}))} /></div>
          <div>
            <label className="label">Roll</label>
            <select className="input" value={staffForm.role} onChange={e => setStaffForm(f => ({...f, role: e.target.value}))}>
              <option value="personal">Stödpedagog / Undersköterska</option>
              <option value="enhetschef">Enhetschef</option>
              <option value="vikarie">Vikarie / Timanställd</option>
              <option value="extern">Extern (MAS/LSS-handläggare)</option>
            </select>
          </div>
          <div><label className="label">Telefon</label><input className="input" value={staffForm.phone} onChange={e => setStaffForm(f => ({...f, phone: e.target.value}))} /></div>
          <div>
            <label className="label">Tillfälligt lösenord * <span className="text-gray-400 font-normal normal-case">(min 12 tecken, versal, siffra, special)</span></label>
            <input type="password" className="input" value={staffForm.password} onChange={e => setStaffForm(f => ({...f, password: e.target.value}))} />
          </div>
          <div className="bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 text-xs text-amber-700">
            Användaren uppmanas att ändra lösenord och aktivera 2FA vid första inloggning.
          </div>
          {staffError && <p className="text-red-600 text-sm bg-red-50 px-3 py-2 rounded-lg">{staffError}</p>}
        </div>
      </Modal>

      {/* Modal: Ny signeringslista */}
      <Modal open={signOpen} onClose={() => setSignOpen(false)} title="Ny signeringslista"
        footer={<>
          <button className="btn btn-secondary" onClick={() => setSignOpen(false)}>Avbryt</button>
          <button className="btn btn-primary" onClick={saveSigning} disabled={signSaving}>{signSaving ? 'Sparar...' : 'Skapa lista'}</button>
        </>}>
        <div className="space-y-4">
          <div><label className="label">Listans namn *</label><input className="input" value={signForm.title} onChange={e => setSignForm(f => ({...f, title: e.target.value}))} placeholder="ex. Medicindelegering mars" /></div>
          <div><label className="label">Period</label><input className="input" value={signForm.period} onChange={e => setSignForm(f => ({...f, period: e.target.value}))} placeholder="ex. Mars 2025" /></div>
          <div>
            <label className="label">Insatser att signera (en per rad) *</label>
            <textarea className="input resize-none h-32" value={signForm.tasks} onChange={e => setSignForm(f => ({...f, tasks: e.target.value}))}
              placeholder={'Morgonrutin\nMedicin AM\nMedicin PM\nKvällsrutin'} />
          </div>
          {signError && <p className="text-red-600 text-sm bg-red-50 px-3 py-2 rounded-lg">{signError}</p>}
        </div>
      </Modal>
    </div>
  )
}
