import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { requireAuth, requireRole } from '@/lib/auth'
import { logAction } from '@/lib/audit'
import { z } from 'zod'

const schema = z.object({
  resident_id: z.string().uuid(),
  template_id: z.string().uuid().optional(),
  title: z.string().min(1),
  category: z.string().optional(),
  fields: z.record(z.string()).default({}),
  valid_from: z.string().optional(),
  valid_until: z.string().optional(),
})

export async function GET(req: NextRequest) {
  try {
    const { user } = await requireAuth()
    const { searchParams } = req.nextUrl
    const residentId = searchParams.get('resident_id')
    const category = searchParams.get('category')

    let query = supabaseAdmin
      .from('documents')
      .select('*, resident:residents(id,full_name,color_code), template:document_templates(id,name,category), created_by_user:users!documents_created_by_fkey(id,full_name)')
      .eq('unit_id', user.unit_id)
      .neq('status', 'archived')
      .order('created_at', { ascending: false })

    if (residentId) query = query.eq('resident_id', residentId)
    if (category) query = query.eq('category', category)

    const { data, error } = await query
    if (error) throw error
    return NextResponse.json({ data })
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : 'Fel'
    if (msg === 'UNAUTHORIZED') return NextResponse.json({ error: 'Ej inloggad' }, { status: 401 })
    return NextResponse.json({ error: msg }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const { user } = await requireRole(['admin', 'enhetschef', 'personal'])
    const body = schema.parse(await req.json())
    const { data, error } = await supabaseAdmin
      .from('documents')
      .insert({ ...body, unit_id: user.unit_id, created_by: user.id, updated_by: user.id, status: 'draft' })
      .select().single()
    if (error) throw error
    await logAction({ user_id: user.id, unit_id: user.unit_id, action: 'create_document', resource_type: 'document', resource_id: data.id })
    return NextResponse.json({ data }, { status: 201 })
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : 'Fel'
    if (msg === 'UNAUTHORIZED') return NextResponse.json({ error: 'Ej inloggad' }, { status: 401 })
    if (msg === 'FORBIDDEN') return NextResponse.json({ error: 'Otillräcklig behörighet' }, { status: 403 })
    return NextResponse.json({ error: msg }, { status: 500 })
  }
}
