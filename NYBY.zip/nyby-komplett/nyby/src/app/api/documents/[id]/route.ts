import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { requireAuth, requireRole } from '@/lib/auth'
import { logAction } from '@/lib/audit'

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { user } = await requireAuth()
    const { data, error } = await supabaseAdmin
      .from('documents')
      .select('*, resident:residents(*), template:document_templates(*), signatures:document_signatures(*, user:users(id,full_name,role))')
      .eq('id', params.id).eq('unit_id', user.unit_id).single()
    if (error) throw error
    return NextResponse.json({ data })
  } catch (e: unknown) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { user } = await requireRole(['admin', 'enhetschef', 'personal'])
    const body = await req.json()
    const { data, error } = await supabaseAdmin
      .from('documents').update({ ...body, updated_by: user.id }).eq('id', params.id).eq('unit_id', user.unit_id).select().single()
    if (error) throw error
    await logAction({ user_id: user.id, unit_id: user.unit_id, action: 'update_document', resource_type: 'document', resource_id: params.id })
    return NextResponse.json({ data })
  } catch (e: unknown) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { user } = await requireRole(['admin', 'enhetschef'])
    await supabaseAdmin.from('documents').update({ status: 'archived' }).eq('id', params.id).eq('unit_id', user.unit_id)
    await logAction({ user_id: user.id, unit_id: user.unit_id, action: 'archive_document', resource_type: 'document', resource_id: params.id })
    return NextResponse.json({ success: true })
  } catch (e: unknown) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}
