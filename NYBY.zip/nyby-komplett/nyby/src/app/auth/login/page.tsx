'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Image from 'next/image'

type Step = 'credentials' | 'totp' | 'totp_setup'

export default function LoginPage() {
  const router = useRouter()
  const [step, setStep] = useState<Step>('credentials')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [totpCode, setTotpCode] = useState('')
  const [userId, setUserId] = useState('')
  const [qrDataUrl, setQrDataUrl] = useState('')
  const [backupCodes, setBackupCodes] = useState<string[]>([])
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleCredentials(e: React.FormEvent) {
    e.preventDefault()
    setError(''); setLoading(true)
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      })
      const data = await res.json()
      if (!res.ok) { setError(data.error); return }
      if (data.requires_totp_setup) {
        setUserId(data.user_id)
        await loadTOTPSetup(data.user_id)
        setStep('totp_setup')
      } else if (data.requires_totp) {
        setStep('totp')
      } else if (data.success) {
        router.push('/dashboard')
      }
    } finally { setLoading(false) }
  }

  async function loadTOTPSetup(uid: string) {
    const res = await fetch(`/api/auth/totp-setup?user_id=${uid}`)
    const data = await res.json()
    setQrDataUrl(data.qr_data_url)
    setBackupCodes(data.backup_codes)
  }

  async function handleTOTP(e: React.FormEvent) {
    e.preventDefault()
    setError(''); setLoading(true)
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, totp_code: totpCode }),
      })
      const data = await res.json()
      if (!res.ok) { setError(data.error); return }
      if (data.success) router.push('/dashboard')
    } finally { setLoading(false) }
  }

  async function handleTOTPSetupVerify(e: React.FormEvent) {
    e.preventDefault()
    setError(''); setLoading(true)
    try {
      const res = await fetch('/api/auth/totp-setup', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: userId, totp_code: totpCode }),
      })
      const data = await res.json()
      if (!res.ok) { setError(data.error); return }
      // Nu inloggad direkt
      const loginRes = await fetch('/api/auth/login', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, totp_code: totpCode }),
      })
      if (loginRes.ok) router.push('/dashboard')
    } finally { setLoading(false) }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1c2030] to-[#2d3452] flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo / Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-accent rounded-2xl mb-4 shadow-lg">
            <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/>
            </svg>
          </div>
          <h1 className="text-white text-2xl font-bold">Nyby Dokumentationssystem</h1>
          <p className="text-gray-400 text-sm mt-1">Humana LSS</p>
        </div>

        <div className="bg-white rounded-2xl shadow-2xl p-8">
          {/* STEG 1: Inloggning */}
          {step === 'credentials' && (
            <>
              <h2 className="text-lg font-semibold text-gray-900 mb-6">Logga in</h2>
              <form onSubmit={handleCredentials} className="space-y-4">
                <div>
                  <label className="label">E-postadress</label>
                  <input className="input" type="email" value={email}
                    onChange={e => setEmail(e.target.value)} placeholder="namn@humana.se" required autoFocus />
                </div>
                <div>
                  <label className="label">Lösenord</label>
                  <input className="input" type="password" value={password}
                    onChange={e => setPassword(e.target.value)} placeholder="••••••••••••" required />
                </div>
                {error && <p className="text-red-600 text-sm bg-red-50 px-3 py-2 rounded-lg">{error}</p>}
                <button type="submit" className="btn btn-primary w-full justify-center py-2.5" disabled={loading}>
                  {loading ? 'Loggar in...' : 'Fortsätt'}
                </button>
              </form>
            </>
          )}

          {/* STEG 2: TOTP-kod */}
          {step === 'totp' && (
            <>
              <button onClick={() => setStep('credentials')} className="text-gray-400 hover:text-gray-600 text-sm mb-4 flex items-center gap-1">
                ← Tillbaka
              </button>
              <div className="flex justify-center mb-4">
                <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center">
                  <svg className="w-6 h-6 text-accent" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
                  </svg>
                </div>
              </div>
              <h2 className="text-lg font-semibold text-gray-900 text-center mb-1">Ange autenticeringskod</h2>
              <p className="text-gray-500 text-sm text-center mb-6">Öppna din authenticator-app och ange den 6-siffriga koden.</p>
              <form onSubmit={handleTOTP} className="space-y-4">
                <input className="input text-center text-2xl tracking-[0.5em] font-mono" type="text"
                  inputMode="numeric" maxLength={6} value={totpCode}
                  onChange={e => setTotpCode(e.target.value.replace(/\D/g, ''))}
                  placeholder="000000" required autoFocus />
                {error && <p className="text-red-600 text-sm bg-red-50 px-3 py-2 rounded-lg">{error}</p>}
                <button type="submit" className="btn btn-primary w-full justify-center py-2.5" disabled={loading || totpCode.length < 6}>
                  {loading ? 'Verifierar...' : 'Logga in'}
                </button>
              </form>
            </>
          )}

          {/* STEG 3: TOTP-setup (första gången) */}
          {step === 'totp_setup' && (
            <>
              <h2 className="text-lg font-semibold text-gray-900 mb-2">Aktivera tvåfaktorautentisering</h2>
              <p className="text-gray-500 text-sm mb-5">
                Skanna QR-koden med Google Authenticator, Authy eller likvärdig app. Ange sedan den 6-siffriga koden för att bekräfta.
              </p>
              {qrDataUrl && (
                <div className="flex justify-center mb-4">
                  <div className="p-3 bg-white border-2 border-gray-200 rounded-xl">
                    <img src={qrDataUrl} alt="TOTP QR-kod" className="w-48 h-48" />
                  </div>
                </div>
              )}
              {backupCodes.length > 0 && (
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-5">
                  <p className="text-amber-800 text-xs font-semibold mb-2">⚠️ SPARA DESSA BACKUP-KODER – visas bara en gång</p>
                  <div className="grid grid-cols-2 gap-1">
                    {backupCodes.map(code => (
                      <code key={code} className="text-xs font-mono bg-white px-2 py-1 rounded border text-amber-900">{code}</code>
                    ))}
                  </div>
                </div>
              )}
              <form onSubmit={handleTOTPSetupVerify} className="space-y-4">
                <div>
                  <label className="label">Bekräfta med kod från appen</label>
                  <input className="input text-center text-2xl tracking-[0.5em] font-mono" type="text"
                    inputMode="numeric" maxLength={6} value={totpCode}
                    onChange={e => setTotpCode(e.target.value.replace(/\D/g, ''))}
                    placeholder="000000" required autoFocus />
                </div>
                {error && <p className="text-red-600 text-sm bg-red-50 px-3 py-2 rounded-lg">{error}</p>}
                <button type="submit" className="btn btn-primary w-full justify-center py-2.5" disabled={loading || totpCode.length < 6}>
                  {loading ? 'Aktiverar...' : 'Aktivera och logga in'}
                </button>
              </form>
            </>
          )}
        </div>

        <p className="text-center text-gray-500 text-xs mt-6">
          © {new Date().getFullYear()} Humana AB · Konfidentiellt
        </p>
      </div>
    </div>
  )
}
