# Nyby Dokumentationssystem

Webbaserat dokumentations- och planeringssystem för Humana LSS-boenden.
Byggt med Next.js 14, Supabase och TOTP-autentisering.

---

## Snabbstart (lokal utveckling)

### 1. Förutsättningar
- Node.js 18+
- Ett Supabase-konto (gratis på supabase.com)

### 2. Klona och installera
```bash
git clone <repo-url> nyby
cd nyby
npm install
```

### 3. Konfigurera miljövariabler
```bash
cp .env.example .env.local
```
Fyll i värdena från ditt Supabase-projekt (Settings → API).

### 4. Sätt upp databasen
Gå till Supabase → SQL Editor och kör:
1. `supabase/migrations/001_initial_schema.sql`
2. `supabase/migrations/002_seed_templates.sql`

### 5. Starta
```bash
npm run dev
# Öppna http://localhost:3000
```

---

## Driftsättning (produktion)

### Supabase (databas + auth)
1. Skapa projekt på [supabase.com](https://supabase.com)
2. Kör SQL-migrationerna via SQL Editor
3. Kopiera URL och anon key till miljövariabler

### Vercel (hosting)
1. Pusha koden till GitHub
2. Importera projektet på [vercel.com](https://vercel.com)
3. Lägg till alla miljövariabler under Project Settings → Environment Variables
4. Deploy automatiskt vid varje push till main

---

## Projektstruktur

```
src/
├── app/
│   ├── api/           # API-routes (Next.js Route Handlers)
│   │   ├── auth/      # Inloggning, TOTP, logout
│   │   ├── residents/ # CRUD boende
│   │   ├── documents/ # CRUD dokument
│   │   ├── staff/     # Personalhantering
│   │   └── planning/  # Aktiviteter och matsedel
│   ├── auth/login/    # Inloggningssida
│   ├── dashboard/     # Skyddade sidor
│   ├── residents/
│   ├── documents/
│   ├── planning/
│   └── staff/
├── components/
│   ├── layout/        # Sidebar, Topbar
│   ├── auth/          # Login-komponenter
│   ├── residents/
│   ├── documents/
│   └── planning/
├── lib/
│   ├── auth.ts        # Session-hantering, JWT
│   ├── totp.ts        # TOTP-generering och verifiering
│   ├── password.ts    # Bcrypt och validering
│   ├── supabase.ts    # Supabase-klienter
│   └── audit.ts       # Audit logging
├── types/index.ts     # TypeScript-typer
└── middleware.ts      # Route-skydd
supabase/
└── migrations/
    ├── 001_initial_schema.sql
    └── 002_seed_templates.sql
```

---

## Roller och behörigheter

| Roll | Åtkomst |
|------|---------|
| `admin` | Full åtkomst, alla enheter |
| `enhetschef` | Full åtkomst inom sin enhet |
| `personal` | Skapa/redigera dokument, se boende |
| `vikarie` | Se dokument, signera insatser |
| `extern` | Läsbehörighet på specificerade boende |

---

## Säkerhet
- Tvåfaktorautentisering (TOTP) krävs för alla användare
- TOTP-hemligheter krypteras med AES-256-CBC i databasen
- JWT-sessioner, 8 timmar, httpOnly cookies
- Row Level Security (RLS) i Supabase – data isoleras per enhet
- Audit log för alla känsliga operationer
- Rate limiting på inloggning (5 försök, sedan 15 min lockout)
- Lösenord hashas med bcrypt (kostnadsfaktor 12)

---

## Miljövariabler

| Variabel | Beskrivning |
|----------|-------------|
| `NEXT_PUBLIC_SUPABASE_URL` | Supabase projekt-URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase anon key |
| `SUPABASE_SERVICE_ROLE_KEY` | Supabase service role (server-only) |
| `JWT_SECRET` | Hemlig nyckel för JWT (min 32 tecken) |
| `NEXT_PUBLIC_APP_URL` | Appens URL (ex. https://nyby.humana.se) |
