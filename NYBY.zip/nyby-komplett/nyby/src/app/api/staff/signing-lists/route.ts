import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { requireAuth } from '@/lib/auth'
import { z } from 'zod'

export async function GET() {
  try {
    const { user } = await requireAuth()
    const { data, error } = await supabaseAdmin
      .from('signing_lists')
      .select('*, entries:signing_entries(*)')
      .eq('unit_id', user.unit_id)
      .eq('active', true)
      .order('created_at', { ascending: false })
    if (error) throw error
    return NextResponse.json({ data })
  } catch (e: unknown) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const { user } = await requireAuth()
    const { title, period, tasks } = z.object({ title: z.string(), period: z.string().optional(), tasks: z.array(z.string()) }).parse(await req.json())
    const { data, error } = await supabaseAdmin
      .from('signing_lists').insert({ title, period, tasks, unit_id: user.unit_id, created_by: user.id }).select().single()
    if (error) throw error
    return NextResponse.json({ data }, { status: 201 })
  } catch (e: unknown) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}
