import { NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { requireAuth } from '@/lib/auth'

export async function GET() {
  try {
    const { user } = await requireAuth()
    const { data, error } = await supabaseAdmin
      .from('document_templates').select('*')
      .or(`unit_id.is.null,unit_id.eq.${user.unit_id}`)
      .eq('active', true).order('category')
    if (error) throw error
    return NextResponse.json({ data })
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : 'Fel'
    if (msg === 'UNAUTHORIZED') return NextResponse.json({ error: 'Ej inloggad' }, { status: 401 })
    return NextResponse.json({ error: msg }, { status: 500 })
  }
}
