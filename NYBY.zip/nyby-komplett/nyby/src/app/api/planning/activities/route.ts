import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { requireAuth } from '@/lib/auth'
import { z } from 'zod'

export async function GET(req: NextRequest) {
  try {
    const { user } = await requireAuth()
    const residentId = req.nextUrl.searchParams.get('resident_id')
    let query = supabaseAdmin.from('activities').select('*, resident:residents(id,full_name,color_code)').eq('unit_id', user.unit_id)
    if (residentId) query = query.eq('resident_id', residentId)
    const { data, error } = await query.order('day_of_week')
    if (error) throw error
    return NextResponse.json({ data })
  } catch (e: unknown) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}

const schema = z.object({
  resident_id: z.string().uuid().optional(),
  title: z.string().min(1),
  description: z.string().optional(),
  day_of_week: z.number().min(1).max(7).optional(),
  time_of_day: z.string().optional(),
  week_date: z.string().optional(),
  is_recurring: z.boolean().default(false),
})

export async function POST(req: NextRequest) {
  try {
    const { user } = await requireAuth()
    const body = schema.parse(await req.json())
    const { data, error } = await supabaseAdmin
      .from('activities').insert({ ...body, unit_id: user.unit_id, created_by: user.id }).select().single()
    if (error) throw error
    return NextResponse.json({ data }, { status: 201 })
  } catch (e: unknown) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}
