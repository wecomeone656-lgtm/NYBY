'use client'
import { useState, useEffect, useCallback } from 'react'

export function useApi<T>(url: string, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchData = useCallback(async () => {
    setLoading(true); setError(null)
    try {
      const res = await fetch(url)
      const json = await res.json()
      if (!res.ok) throw new Error(json.error || 'Fel vid hämtning')
      setData(json.data)
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Okänt fel')
    } finally { setLoading(false) }
  }, [url])

  useEffect(() => { fetchData() }, [fetchData, ...deps])
  return { data, loading, error, refetch: fetchData }
}

export async function apiPost<T>(url: string, body: unknown): Promise<{ data?: T; error?: string }> {
  try {
    const res = await fetch(url, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    })
    const json = await res.json()
    if (!res.ok) return { error: json.error || 'Fel' }
    return { data: json.data }
  } catch { return { error: 'Nätverksfel' } }
}

export async function apiPatch<T>(url: string, body: unknown): Promise<{ data?: T; error?: string }> {
  try {
    const res = await fetch(url, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    })
    const json = await res.json()
    if (!res.ok) return { error: json.error || 'Fel' }
    return { data: json.data }
  } catch { return { error: 'Nätverksfel' } }
}

export async function apiDelete(url: string): Promise<{ error?: string }> {
  try {
    const res = await fetch(url, { method: 'DELETE' })
    if (!res.ok) { const j = await res.json(); return { error: j.error } }
    return {}
  } catch { return { error: 'Nätverksfel' } }
}
