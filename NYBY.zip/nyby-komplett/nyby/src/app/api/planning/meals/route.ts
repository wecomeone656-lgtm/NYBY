import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { requireAuth } from '@/lib/auth'
import { z } from 'zod'

export async function GET(req: NextRequest) {
  try {
    const { user } = await requireAuth()
    const week = req.nextUrl.searchParams.get('week')
    const year = req.nextUrl.searchParams.get('year')
    let query = supabaseAdmin.from('meals').select('*').eq('unit_id', user.unit_id)
    if (week) query = query.eq('week_number', parseInt(week))
    if (year) query = query.eq('year', parseInt(year))
    const { data, error } = await query.order('day_of_week')
    if (error) throw error
    return NextResponse.json({ data })
  } catch (e: unknown) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}

const schema = z.object({
  week_number: z.number(), year: z.number(),
  day_of_week: z.number().min(1).max(7),
  meal_type: z.string(), description: z.string(),
})

export async function POST(req: NextRequest) {
  try {
    const { user } = await requireAuth()
    const body = schema.parse(await req.json())
    const { data, error } = await supabaseAdmin
      .from('meals')
      .upsert({ ...body, unit_id: user.unit_id, created_by: user.id }, { onConflict: 'unit_id,week_number,year,day_of_week,meal_type' })
      .select().single()
    if (error) throw error
    return NextResponse.json({ data })
  } catch (e: unknown) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}
