-- ─── INBYGGDA DOKUMENTMALLAR ──────────────────────────────────
INSERT INTO document_templates (category, name, description, is_system, fields) VALUES

('genomforandeplan', 'Genomförandeplan', 'Individuell plan för hur insatser ska genomföras', true,
'[
  {"key":"mal","label":"Mål med insatsen","type":"textarea","required":true},
  {"key":"metod","label":"Metod och genomförande","type":"textarea","required":true},
  {"key":"ansvarig","label":"Ansvarig personal","type":"text","required":true},
  {"key":"uppfoljning","label":"Uppföljningsdatum","type":"date","required":true},
  {"key":"vilja","label":"Boendets egna önskemål och vilja","type":"textarea","required":false},
  {"key":"styrkor","label":"Resurser och styrkor","type":"textarea","required":false},
  {"key":"narvaro","label":"Boendets delaktighet i planen","type":"select","required":true,
   "options":["Deltog aktivt","Deltog delvis","Kunde ej delta – se anteckning"]}
]'),

('skyddsatgard', 'Samtyckesblankett – Skyddsåtgärd', 'Dokumentation av samtycke till skyddsåtgärd', true,
'[
  {"key":"atgard","label":"Beskrivning av åtgärd","type":"textarea","required":true},
  {"key":"syfte","label":"Syfte och motivering","type":"textarea","required":true},
  {"key":"alternativ","label":"Alternativ som prövats","type":"textarea","required":true},
  {"key":"samtycke","label":"Samtycke lämnat av","type":"text","required":true},
  {"key":"samtyckesdatum","label":"Datum för samtycke","type":"date","required":true},
  {"key":"giltighetstid","label":"Giltighetstid","type":"text","required":true},
  {"key":"uppfoljning","label":"Uppföljning och utvärdering","type":"textarea","required":false}
]'),

('avvikelse', 'Avvikelserapport', 'Rapportering av avvikelse i vård och omsorg', true,
'[
  {"key":"datum","label":"Datum och tid för händelsen","type":"datetime-local","required":true},
  {"key":"beskrivning","label":"Beskrivning av händelsen","type":"textarea","required":true},
  {"key":"orsak","label":"Trolig orsak","type":"textarea","required":false},
  {"key":"atgard","label":"Åtgärd vid händelsen","type":"textarea","required":true},
  {"key":"forebygg","label":"Förebyggande åtgärd","type":"textarea","required":false},
  {"key":"rapporterad_till","label":"Rapporterad till","type":"text","required":true},
  {"key":"allvar","label":"Allvarlighetsgrad","type":"select","required":true,
   "options":["Låg – ingen skada","Medel – lindrig skada","Hög – allvarlig skada","Kritisk – livshotande"]}
]'),

('bemotanderutin', 'Bemötanderutin', 'Individuell rutin för bemötande och kommunikation', true,
'[
  {"key":"komm","label":"Kommunikationssätt och hjälpmedel","type":"textarea","required":true},
  {"key":"triggers","label":"Kända triggers och varningssignaler","type":"textarea","required":false},
  {"key":"lugn","label":"Lugnande strategier som fungerar","type":"textarea","required":true},
  {"key":"undvik","label":"Saker att undvika","type":"textarea","required":true},
  {"key":"styrkor","label":"Personliga styrkor och intressen","type":"textarea","required":false},
  {"key":"rutiner","label":"Viktiga rutiner och strukturer","type":"textarea","required":false}
]'),

('kost_vatska', 'Mat- och vätskeprotokoll', 'Dokumentation av kostbehov och vätskeintag', true,
'[
  {"key":"kosttyp","label":"Kosttyp och specialkost","type":"text","required":true},
  {"key":"allergi","label":"Allergier och överkänslighet","type":"textarea","required":false},
  {"key":"pref","label":"Matpreferenser och ogillanden","type":"textarea","required":false},
  {"key":"hjalp","label":"Behov av hjälp vid måltid","type":"textarea","required":false},
  {"key":"vatska_mal","label":"Dagligt vätskedricksmål (ml)","type":"number","required":false},
  {"key":"rutinvat","label":"Rutin för vätskedokumentation","type":"textarea","required":false}
]'),

('delegering', 'Delegering – Läkemedel', 'Delegering av läkemedelshantering', true,
'[
  {"key":"delegerat_av","label":"Delegerat av (sjuksköterska)","type":"text","required":true},
  {"key":"delegerat_till","label":"Delegerat till (personal)","type":"text","required":true},
  {"key":"lakemedelslista","label":"Läkemedel som delegeras (ett per rad)","type":"textarea","required":true},
  {"key":"giltig_from","label":"Giltig från","type":"date","required":true},
  {"key":"giltig_tom","label":"Giltig till","type":"date","required":true},
  {"key":"villkor","label":"Särskilda villkor och instruktioner","type":"textarea","required":false}
]');

