'use client'
import { useApi } from '@/hooks/useApi'
import StatCard from '@/components/ui/StatCard'
import Spinner from '@/components/ui/Spinner'
import Link from 'next/link'
import type { Resident, Document } from '@/types'

export default function DashboardPage() {
  const { data: residents, loading: rLoad } = useApi<Resident[]>('/api/residents')
  const { data: docs, loading: dLoad } = useApi<Document[]>('/api/documents')

  if (rLoad || dLoad) return <Spinner size="lg" />

  const resList = residents || []
  const docList = docs || []
  const mon = new Date().toISOString().slice(0, 7)
  const avvCount = docList.filter(d => d.category === 'avvikelse' && d.created_at?.slice(0, 7) === mon).length
  const gpCount = docList.filter(d => d.category === 'genomforandeplan').length
  const recentDocs = [...docList].sort((a, b) => b.created_at.localeCompare(a.created_at)).slice(0, 6)

  const catLabel: Record<string, string> = {
    genomforandeplan: 'Genomförandeplan', skyddsatgard: 'Skyddsåtgärd',
    avvikelse: 'Avvikelse', bemotanderutin: 'Bemötanderutin',
    kost_vatska: 'Kost & Vätska', delegering: 'Delegering', signering: 'Signering',
  }
  const catColor: Record<string, 'blue'|'green'|'red'|'yellow'|'gray'|'purple'> = {
    genomforandeplan: 'blue', skyddsatgard: 'red', avvikelse: 'yellow',
    bemotanderutin: 'green', kost_vatska: 'purple', delegering: 'gray',
  }

  return (
    <div className="space-y-6">
      {/* Statistikrad */}
      <div className="grid grid-cols-4 gap-4">
        <StatCard value={resList.length} label="Boende" color="#4a7cf7" icon="👥" />
        <StatCard value={docList.length} label="Dokument totalt" color="#5db88a" icon="📝" />
        <StatCard value={avvCount} label="Avvikelser denna månad" color="#e8b84b" icon="⚠️" />
        <StatCard value={gpCount} label="Genomförandeplaner" color="#9b72e8" icon="📋" />
      </div>

      <div className="grid grid-cols-2 gap-6">
        {/* Boende */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Boende</h3>
            <Link href="/residents" className="text-xs text-accent hover:underline">Visa alla</Link>
          </div>
          <div className="space-y-2">
            {resList.map(r => {
              const rDocs = docList.filter(d => d.resident_id === r.id)
              return (
                <Link key={r.id} href={`/documents?resident_id=${r.id}`}
                  className="flex items-center justify-between bg-white border border-gray-200 rounded-xl px-4 py-3 hover:border-accent/40 hover:shadow-sm transition-all group">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full flex items-center justify-center text-white text-sm font-bold flex-shrink-0"
                      style={{ background: r.color_code }}>{r.full_name[0]}</div>
                    <div>
                      <div className="text-sm font-semibold text-gray-900 group-hover:text-accent transition-colors">{r.full_name}</div>
                      <div className="text-xs text-gray-400">Rum {r.room_number} · {r.lss_decision}</div>
                    </div>
                  </div>
                  <span className="text-xs bg-gray-100 text-gray-500 px-2.5 py-1 rounded-full font-medium">{rDocs.length} dok</span>
                </Link>
              )
            })}
            {resList.length === 0 && (
              <div className="bg-white border border-gray-200 rounded-xl p-6 text-center text-gray-400 text-sm">
                Inga boende registrerade.{' '}
                <Link href="/residents" className="text-accent hover:underline">Lägg till</Link>
              </div>
            )}
          </div>
        </div>

        {/* Senaste dokumentation */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Senaste dokumentation</h3>
            <Link href="/documents" className="text-xs text-accent hover:underline">Visa alla</Link>
          </div>
          <div className="space-y-2">
            {recentDocs.map(doc => {
              const cat = doc.category || 'ovrigt'
              return (
                <Link key={doc.id} href={`/documents/${doc.id}`}
                  className="flex items-center justify-between bg-white border border-gray-200 rounded-xl px-4 py-3 hover:border-accent/40 hover:shadow-sm transition-all group">
                  <div className="flex items-center gap-3 min-w-0">
                    {doc.resident && (
                      <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: doc.resident.color_code }} />
                    )}
                    <div className="min-w-0">
                      <div className="text-sm font-semibold text-gray-900 truncate group-hover:text-accent">{doc.title}</div>
                      <div className="text-xs text-gray-400">{doc.resident?.full_name} · {doc.created_at.slice(0, 10)}</div>
                    </div>
                  </div>
                  <span className={`badge ${catColor[cat] === 'blue' ? 'bg-blue-50 text-blue-700' : catColor[cat] === 'yellow' ? 'bg-amber-50 text-amber-700' : 'bg-gray-100 text-gray-600'} text-xs ml-2 flex-shrink-0`}>
                    {catLabel[cat] || 'Dokument'}
                  </span>
                </Link>
              )
            })}
            {recentDocs.length === 0 && (
              <div className="bg-white border border-gray-200 rounded-xl p-6 text-center text-gray-400 text-sm">
                Inga dokument än.{' '}
                <Link href="/templates" className="text-accent hover:underline">Skapa från mall</Link>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Genvägar */}
      <div>
        <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Snabbåtgärder</h3>
        <div className="grid grid-cols-4 gap-3">
          {[
            { href: '/templates', label: 'Nytt dokument', icon: '📄', color: '#4a7cf7' },
            { href: '/residents', label: 'Lägg till boende', icon: '👤', color: '#5db88a' },
            { href: '/planning', label: 'Uppdatera matsedel', icon: '🍽️', color: '#e8b84b' },
            { href: '/staff', label: 'Signeringslistor', icon: '✅', color: '#9b72e8' },
          ].map(item => (
            <Link key={item.href} href={item.href}
              className="bg-white border border-gray-200 rounded-xl p-4 flex items-center gap-3 hover:border-gray-300 hover:shadow-sm transition-all group">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center text-xl flex-shrink-0"
                style={{ background: item.color + '18' }}>{item.icon}</div>
              <span className="text-sm font-medium text-gray-700 group-hover:text-gray-900">{item.label}</span>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
