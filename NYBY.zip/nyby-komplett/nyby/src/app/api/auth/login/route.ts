import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { supabaseAdmin } from '@/lib/supabase'
import { verifyPassword } from '@/lib/password'
import { verifyTOTP, verifyBackupCode } from '@/lib/totp'
import { createSession } from '@/lib/auth'
import { logAction } from '@/lib/audit'

const schema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
  totp_code: z.string().optional(),
})

export async function POST(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for') || 'unknown'
  try {
    const { email, password, totp_code } = schema.parse(await req.json())
    const { data: user } = await supabaseAdmin
      .from('users').select('*').eq('email', email.toLowerCase()).eq('active', true).single()

    if (!user) return NextResponse.json({ error: 'Felaktig e-post eller lösenord' }, { status: 401 })

    if (user.locked_until && new Date(user.locked_until) > new Date())
      return NextResponse.json({ error: 'Kontot är tillfälligt låst.' }, { status: 429 })

    const pwOk = await verifyPassword(password, user.password_hash)
    if (!pwOk) {
      const attempts = (user.failed_login_attempts || 0) + 1
      const upd: Record<string, unknown> = { failed_login_attempts: attempts }
      if (attempts >= 5) upd.locked_until = new Date(Date.now() + 15 * 60 * 1000).toISOString()
      await supabaseAdmin.from('users').update(upd).eq('id', user.id)
      return NextResponse.json({ error: 'Felaktig e-post eller lösenord' }, { status: 401 })
    }

    if (!user.totp_enabled) {
      return NextResponse.json({ requires_totp_setup: true, user_id: user.id })
    }

    if (!totp_code) {
      return NextResponse.json({ requires_totp: true })
    }

    const totpOk = verifyTOTP(user.totp_secret, totp_code)
    if (!totpOk) {
      const backup = await verifyBackupCode(totp_code, user.backup_codes || [])
      if (backup.valid) {
        const codes = [...user.backup_codes]
        codes.splice(backup.index, 1)
        await supabaseAdmin.from('users').update({ backup_codes: codes }).eq('id', user.id)
      } else {
        return NextResponse.json({ error: 'Ogiltig autenticeringskod' }, { status: 401 })
      }
    }

    await supabaseAdmin.from('users').update({
      failed_login_attempts: 0, locked_until: null,
      last_login_at: new Date().toISOString(),
    }).eq('id', user.id)

    const token = await createSession(user)
    await logAction({ user_id: user.id, unit_id: user.unit_id, action: 'login', ip_address: ip })

    const res = NextResponse.json({ success: true, user: {
      id: user.id, email: user.email, full_name: user.full_name,
      role: user.role, unit_id: user.unit_id,
    }})
    res.cookies.set('nyby_session', token, {
      httpOnly: true, secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax', maxAge: 8 * 60 * 60, path: '/',
    })
    return res
  } catch (e) {
    console.error(e)
    return NextResponse.json({ error: 'Något gick fel' }, { status: 500 })
  }
}
