interface Props { icon?: string; title: string; description?: string; action?: React.ReactNode }
export default function EmptyState({ icon = '📄', title, description, action }: Props) {
  return (
    <div className="text-center py-16 px-6">
      <div className="text-4xl mb-3">{icon}</div>
      <h3 className="font-semibold text-gray-700 mb-1">{title}</h3>
      {description && <p className="text-sm text-gray-400 mb-4">{description}</p>}
      {action}
    </div>
  )
}
