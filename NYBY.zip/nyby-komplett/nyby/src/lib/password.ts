import bcrypt from 'bcryptjs'
import { z } from 'zod'

export const passwordSchema = z
  .string()
  .min(12, 'Lösenordet måste vara minst 12 tecken')
  .regex(/[A-Z]/, 'Måste innehålla minst en versal')
  .regex(/[0-9]/, 'Måste innehålla minst en siffra')
  .regex(/[^A-Za-z0-9]/, 'Måste innehålla minst ett specialtecken')

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12)
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash)
}
