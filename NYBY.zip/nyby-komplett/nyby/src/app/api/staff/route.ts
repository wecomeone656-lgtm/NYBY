import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { requireAuth, requireRole } from '@/lib/auth'
import { hashPassword } from '@/lib/password'
import { z } from 'zod'

const schema = z.object({
  email: z.string().email(),
  full_name: z.string().min(1),
  role: z.enum(['enhetschef','personal','vikarie','extern']),
  phone: z.string().optional(),
  password: z.string().min(12),
})

export async function GET() {
  try {
    const { user } = await requireRole(['admin', 'enhetschef'])
    const { data, error } = await supabaseAdmin
      .from('users')
      .select('id,email,full_name,role,phone,active,totp_enabled,last_login_at,created_at')
      .eq('unit_id', user.unit_id)
      .order('full_name')
    if (error) throw error
    return NextResponse.json({ data })
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : 'Fel'
    if (msg === 'UNAUTHORIZED') return NextResponse.json({ error: 'Ej inloggad' }, { status: 401 })
    if (msg === 'FORBIDDEN') return NextResponse.json({ error: 'Otillräcklig behörighet' }, { status: 403 })
    return NextResponse.json({ error: msg }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const { user } = await requireRole(['admin', 'enhetschef'])
    const body = schema.parse(await req.json())
    const password_hash = await hashPassword(body.password)
    const { data, error } = await supabaseAdmin
      .from('users')
      .insert({ email: body.email.toLowerCase(), full_name: body.full_name, role: body.role, phone: body.phone, password_hash, unit_id: user.unit_id, must_change_password: true })
      .select('id,email,full_name,role').single()
    if (error) {
      if (error.code === '23505') return NextResponse.json({ error: 'E-postadressen används redan' }, { status: 409 })
      throw error
    }
    return NextResponse.json({ data }, { status: 201 })
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : 'Fel'
    if (msg === 'UNAUTHORIZED') return NextResponse.json({ error: 'Ej inloggad' }, { status: 401 })
    if (msg === 'FORBIDDEN') return NextResponse.json({ error: 'Otillräcklig behörighet' }, { status: 403 })
    return NextResponse.json({ error: msg }, { status: 500 })
  }
}
