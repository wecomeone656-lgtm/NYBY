import { NextRequest, NextResponse } from 'next/server'
import { verifySession } from '@/lib/auth'

const PUBLIC_PATHS = ['/auth/login', '/api/auth/login', '/api/auth/totp-setup']

export async function middleware(req: NextRequest) {
  const path = req.nextUrl.pathname
  const isPublic = PUBLIC_PATHS.some(p => path.startsWith(p))

  if (isPublic) return NextResponse.next()

  const token = req.cookies.get('nyby_session')?.value
  if (!token) return NextResponse.redirect(new URL('/auth/login', req.url))

  const payload = await verifySession(token)
  if (!payload) {
    const res = NextResponse.redirect(new URL('/auth/login', req.url))
    res.cookies.delete('nyby_session')
    return res
  }

  // Lägg till user-info i request headers för server components
  const requestHeaders = new Headers(req.headers)
  requestHeaders.set('x-user-id', payload.sub)
  requestHeaders.set('x-user-role', payload.role)
  requestHeaders.set('x-unit-id', payload.unit_id)

  return NextResponse.next({ request: { headers: requestHeaders } })
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|public).*)'],
}
