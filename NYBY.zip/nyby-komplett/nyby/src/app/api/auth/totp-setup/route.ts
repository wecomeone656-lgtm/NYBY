import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { generateTOTPSetup, verifyTOTP } from '@/lib/totp'
import { z } from 'zod'

export async function GET(req: NextRequest) {
  const userId = req.nextUrl.searchParams.get('user_id')
  if (!userId) return NextResponse.json({ error: 'user_id krävs' }, { status: 400 })
  const { data: user } = await supabaseAdmin.from('users').select('email').eq('id', userId).single()
  if (!user) return NextResponse.json({ error: 'Användare ej funnen' }, { status: 404 })
  const setup = await generateTOTPSetup(user.email)
  await supabaseAdmin.from('users').update({
    totp_secret: setup.encryptedSecret, backup_codes: setup.hashedBackupCodes,
  }).eq('id', userId)
  return NextResponse.json({ qr_data_url: setup.qrDataUrl, backup_codes: setup.backupCodes })
}

export async function POST(req: NextRequest) {
  try {
    const { user_id, totp_code } = z.object({ user_id: z.string(), totp_code: z.string().length(6) }).parse(await req.json())
    const { data: user } = await supabaseAdmin.from('users').select('totp_secret').eq('id', user_id).single()
    if (!user?.totp_secret) return NextResponse.json({ error: 'Ingen hemlighet hittades' }, { status: 400 })
    if (!verifyTOTP(user.totp_secret, totp_code)) return NextResponse.json({ error: 'Ogiltig kod' }, { status: 400 })
    await supabaseAdmin.from('users').update({ totp_enabled: true, totp_verified_at: new Date().toISOString() }).eq('id', user_id)
    return NextResponse.json({ success: true })
  } catch {
    return NextResponse.json({ error: 'Fel vid verifiering' }, { status: 500 })
  }
}
